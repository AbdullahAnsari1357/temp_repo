module tb_top;
  // macro includes
  `include "uvm_macros.svh"

  // import packages
  import uvm_pkg::*;
  
  // -------------------------------------------------------------
  // 1. Interfaces
  // -------------------------------------------------------------
  clk_rst_if clk_rst_if();
  fetch_if fetch_if(.clk(clk_rst_if.clk), .rst_n(clk_rst_if.rst_n));
  bram_if bram_if(.clk(clk_rst_if.clk), .rst_n(clk_rst_if.rst_n));
  hbm_if hbm_if(.clk(clk_rst_if.clk), .rst_n(clk_rst_if.rst_n));

  // -------------------------------------------------------------
  // 2. Module Instantiations
  // -------------------------------------------------------------

  store store_inst (
    .clk(clk_rst_if.clk),
    .rst_n(clk_rst_if.rst_n),

    // From fetch
    .store_queue_tdata(fetch_if.store_queue_tdata),
    .store_queue_tvalid(fetch_if.store_queue_tvalid),
    .store_queue_tready(fetch_if.store_queue_tready),

    // To BRAM
    .out_mem_addr_a(bram_if.out_mem_addr_a),
    .out_mem_en_a(bram_if.out_mem_en_a),
    .out_mem_din_a(bram_if.out_mem_din_a),
    .out_mem_dout_a(bram_if.out_mem_dout_a),
    .out_mem_wen_a(bram_if.out_mem_wen_a),

    // AXI (HBM)
    .m_axi_awaddr(hbm_if.m_axi_awaddr),
    .m_axi_awlen(hbm_if.m_axi_awlen),
    .m_axi_awsize(hbm_if.m_axi_awsize),
    .m_axi_awburst(hbm_if.m_axi_awburst),
    .m_axi_awvalid(hbm_if.m_axi_awvalid),
    .m_axi_awready(hbm_if.m_axi_awready),
    .m_axi_wdata(hbm_if.m_axi_wdata),
    .m_axi_wstrb(hbm_if.m_axi_wstrb),
    .m_axi_wvalid(hbm_if.m_axi_wvalid),
    .m_axi_wready(hbm_if.m_axi_wready),
    .m_axi_wlast(hbm_if.m_axi_wlast),
    .m_axi_bvalid(hbm_if.m_axi_bvalid),
    .m_axi_bready(hbm_if.m_axi_bready),
    .m_axi_bresp(hbm_if.m_axi_bresp),

    // Sync signals
    .s_axis_sync_q_0_tdata(bram_if.s_axis_sync_q_0_tdata),
    .s_axis_sync_q_0_tvalid(bram_if.s_axis_sync_q_0_tvalid),
    .s_axis_sync_q_0_tready(bram_if.s_axis_sync_q_0_tready),
    .s_axis_sync_q_1_tdata(bram_if.s_axis_sync_q_1_tdata),
    .s_axis_sync_q_1_tvalid(bram_if.s_axis_sync_q_1_tvalid),
    .s_axis_sync_q_1_tready(bram_if.s_axis_sync_q_1_tready),
    .s_axis_sync_q_2_tdata(bram_if.s_axis_sync_q_2_tdata),
    .s_axis_sync_q_2_tvalid(bram_if.s_axis_sync_q_2_tvalid),
    .s_axis_sync_q_2_tready(bram_if.s_axis_sync_q_2_tready),
    .s_axis_sync_q_3_tdata(bram_if.s_axis_sync_q_3_tdata),
    .s_axis_sync_q_3_tvalid(bram_if.s_axis_sync_q_3_tvalid),
    .s_axis_sync_q_3_tready(bram_if.s_axis_sync_q_3_tready),

    // Reverse syncs
    .s2g_sync_queue_0_tdata(bram_if.s2g_sync_queue_0_tdata),
    .s2g_sync_queue_0_tvalid(bram_if.s2g_sync_queue_0_tvalid),
    .s2g_sync_queue_0_tready(bram_if.s2g_sync_queue_0_tready),
    .s2g_sync_queue_1_tdata(bram_if.s2g_sync_queue_1_tdata),
    .s2g_sync_queue_1_tvalid(bram_if.s2g_sync_queue_1_tvalid),
    .s2g_sync_queue_1_tready(bram_if.s2g_sync_queue_1_tready),
    .s2g_sync_queue_2_tdata(bram_if.s2g_sync_queue_2_tdata),
    .s2g_sync_queue_2_tvalid(bram_if.s2g_sync_queue_2_tvalid),
    .s2g_sync_queue_2_tready(bram_if.s2g_sync_queue_2_tready),
    .s2g_sync_queue_3_tdata(bram_if.s2g_sync_queue_3_tdata),
    .s2g_sync_queue_3_tvalid(bram_if.s2g_sync_queue_3_tvalid),
    .s2g_sync_queue_3_tready(bram_if.s2g_sync_queue_3_tready),

    .barrier_response_store(bram_if.barrier_response_store),
    .error_store(bram_if.error_store),
    .store_valid(bram_if.store_valid)
  );

  // -------------------------------------------------------------
  // 4. Pass Interfaces and Run test
  // -------------------------------------------------------------

  initial begin
    // Pass interface to virtual sequencer
    uvm_config_db#(virtual clk_rst_if)::set(null, "uvm_test_top*", "clk_rst_vif", clk_rst_if);
    uvm_config_db#(virtual fetch_if.DRV_MP)::set(null, "uvm_test_top*", "vif", fetch_if.DRV_MP);
    uvm_config_db#(virtual fetch_if.MON_MP)::set(null, "uvm_test_top*", "vif", fetch_if.MON_MP);
    uvm_config_db#(virtual bram_if.DRV_MP)::set(null, "uvm_test_top*", "vif", bram_if.DRV_MP);
    uvm_config_db#(virtual bram_if.MON_MP)::set(null, "uvm_test_top*", "vif", bram_if.MON_MP);
    uvm_config_db#(virtual hbm_if.DRV_MP)::set(null, "uvm_test_top*", "vif", hbm_if.DRV_MP);
    uvm_config_db#(virtual hbm_if.MON_MP)::set(null, "uvm_test_top*", "vif", hbm_if.MON_MP);    
    run_test();
  end

  // initial begin
  //   // Wait for initial reset to complete
  //   wait (clk_rst_if.rst_n === 1'b1);

  //   // Start monitoring B channel
  //   fork
  //     reset_on_axi_b();
  //   join_none
  // end


  initial begin
    string fsdb_name;
    // Check if a custom name was passed from the Makefile
    if ($value$plusargs("FSDB_NAME=%s", fsdb_name)) begin
        $fsdbDumpfile(fsdb_name);
    end else begin
        $fsdbDumpfile("store_tb.fsdb"); // Fallback default
    end
    // Dump all signals from TB, DUT, and interfaces
    $fsdbDumpvars(0, tb_top.clk_rst_if);
    $fsdbDumpvars(0, tb_top.fetch_if);
    $fsdbDumpvars(0, tb_top.bram_if);
    $fsdbDumpvars(0, tb_top.hbm_if);

    // Optional: for arrays/assertions/SVA
    $fsdbDumpMDA;
    $fsdbDumpSVA;
  end

  // initial begin
  //   string fsdb_file;
  //   fsdb_file = "store_tb.fsdb";

  //   $display("[%0t] INFO: Starting FSDB dump -> %s", $time, fsdb_file);
  //   $fsdbDumpfile(fsdb_file);

  //   // Dump all signals from TB, DUT, and interfaces
  //   $fsdbDumpvars(0, tb_top.clk_rst_if);
  //   $fsdbDumpvars(0, tb_top.fetch_if);
  //   $fsdbDumpvars(0, tb_top.bram_if);
  //   $fsdbDumpvars(0, tb_top.hbm_if);
  // //  $fsdbDumpvars(0, tb_top.store_inst);

  //   // Optional: for arrays/assertions/SVA
  //   $fsdbDumpMDA;
  //   $fsdbDumpSVA;
  // end

  // -------------------------------------------------------------
  // 5. Retrieve Internal Signals of DUT
  // -------------------------------------------------------------

  assign bram_if.axi_str_handshake = store_inst.axi_str_handshake;
  assign fetch_if.ready_for_next_insn = store_inst.ready_for_next_insn;


  task automatic reset_on_axi_b();
    forever begin
      @(posedge clk_rst_if.clk);

      if (hbm_if.m_axi_bvalid && hbm_if.m_axi_bready) begin
        `uvm_info("TB_RST",
          "AXI B handshake detected -> applying TB reset",
          UVM_LOW)

        // Apply reset for 2 cycles (safe + short)
        clk_rst_if.apply_reset(2);
      end
    end
  endtask

endmodule
