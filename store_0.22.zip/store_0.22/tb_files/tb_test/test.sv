//============================================================
// Test : test
// Description : Top-level generic test class
//============================================================
class test extends uvm_test;
  `uvm_component_utils(test)

  env      env;
  test_cfg m_cfg;
  string vseq_name;

  function new(string name = "test", uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    // ------------------------------------------
    // PLUSARG OVERRIDE FOR VIRTUAL SEQUENCE
    // ------------------------------------------

    if ($value$plusargs("VSEQ=%s", vseq_name)) begin
      `uvm_info("TEST", $sformatf("Overriding st_base_vseq with %s", vseq_name), UVM_LOW)
      uvm_factory::get().set_type_override_by_name("st_base_vseq", vseq_name);
    end

    // ------------------------------------------
    // Create Test Config
    // ------------------------------------------

    m_cfg = test_cfg::type_id::create("m_cfg");

    m_cfg.m_env_cfg.fetch_cfg.is_active = UVM_ACTIVE;
    m_cfg.m_env_cfg.bram_cfg.is_active  = UVM_ACTIVE;
    m_cfg.m_env_cfg.hbm_cfg.is_active   = UVM_ACTIVE;

    // ------------------------------------------------------
    // Get Test Config having interface data (set by top.sv)
    // ------------------------------------------------------

    //Fetch the virtual interface from the DB (set by tb_top) and put it INTO the agent config inside m_cfg
    if (!uvm_config_db#(virtual fetch_if.DRV_MP)::get(this, "", "vif", m_cfg.m_env_cfg.fetch_cfg.vif_drv)) begin
      `uvm_fatal("TEST", "Could not get virtual interface 'vif' from tb_top")
    end

    if (!uvm_config_db#(virtual fetch_if.MON_MP)::get(this, "", "vif", m_cfg.m_env_cfg.fetch_cfg.vif_mon)) begin
      `uvm_fatal("TEST", "Could not get virtual interface 'vif' from tb_top")
    end

    if (!uvm_config_db#(virtual bram_if.DRV_MP)::get(this, "", "vif", m_cfg.m_env_cfg.bram_cfg.vif_drv)) begin
      `uvm_fatal("TEST", "Could not get virtual interface 'vif' from tb_top")
    end

    if (!uvm_config_db#(virtual bram_if.MON_MP)::get(this, "", "vif", m_cfg.m_env_cfg.bram_cfg.vif_mon)) begin
      `uvm_fatal("TEST", "Could not get virtual interface 'vif' from tb_top")
    end

    if (!uvm_config_db#(virtual hbm_if.DRV_MP)::get(this, "", "vif", m_cfg.m_env_cfg.hbm_cfg.vif_drv)) begin
      `uvm_fatal("TEST", "Could not get virtual interface 'vif' from tb_top")
    end

    if (!uvm_config_db#(virtual hbm_if.MON_MP)::get(this, "", "vif", m_cfg.m_env_cfg.hbm_cfg.vif_mon)) begin
      `uvm_fatal("TEST", "Could not get virtual interface 'vif' from tb_top")
    end
    
    // ------------------------------------------
    // Passing onto environment
    // ------------------------------------------
    
    uvm_config_db#(env_cfg)::set(this, "env", "cfg", m_cfg.m_env_cfg);

    // ------------------------------------------
    // Create ENV
    // ------------------------------------------
    env = env_pkg::env::type_id::create("env", this);
  endfunction

  task run_phase(uvm_phase phase);

    st_base_vseq vseq;
    
    phase.raise_objection(this);
    vseq = st_base_vseq::type_id::create("vseq");
    if (vseq == null) begin
    `uvm_fatal("TEST", "Failed to create virtual sequence via factory!")
    end
    `uvm_info("TEST", $sformatf("Starting virtual sequence: %s", vseq.get_type_name()), UVM_LOW)
    vseq.start(env.vseqr);
    #100ns;
    phase.drop_objection(this);

  endtask
endclass