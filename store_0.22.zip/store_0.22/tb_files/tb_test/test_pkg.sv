package test_pkg;

  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import env_pkg::*;

  `include "test_cfg.sv"
  `include "test.sv"

endpackage