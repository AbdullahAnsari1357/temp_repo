//============================================================
// Configuration : hbm_agent_cfg
//============================================================

class hbm_agent_cfg extends uvm_object;

  `uvm_object_utils(hbm_agent_cfg)

  uvm_active_passive_enum is_active = UVM_ACTIVE;

  virtual hbm_if.DRV_MP vif_drv;
  virtual hbm_if.MON_MP vif_mon;

  function new(string name = "hbm_agent_cfg");
    super.new(name);
  endfunction

endclass