//============================================================
// Sequencer : hbm_sequencer
//============================================================

class hbm_sequencer extends uvm_sequencer #(hbm_item);

  `uvm_component_utils(hbm_sequencer)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

endclass