//============================================================
// Monitor : hbm_monitor
// Description : Observes AXI Write Transactions (AW + W)
//               Maintains Internal HBM Memory Model
//============================================================

class hbm_monitor extends uvm_monitor;

  `uvm_component_utils(hbm_monitor)

  // ---------------------------------------------------------
  // Class Members
  // ---------------------------------------------------------
  virtual hbm_if.MON_MP vif;
  hbm_agent_cfg         cfg;

  uvm_analysis_port #(hbm_item) analysis_port;

  // ---------------------------------------------------------
  // HBM MEMORY MODEL (Byte Addressable)
  // ---------------------------------------------------------
  // Dynamic width based on your design
  localparam WIDE_WIDTH = (`AIACC_PE_DATA_WIDTH * `AIACC_SA_SIZE);
  localparam NUM_BYTES  = WIDE_WIDTH / 8;

  bit [WIDE_WIDTH-1:0] hbm_mem [longint unsigned];
  
  longint unsigned aligned_addr;

  // ---------------------------------------------------------
  // AW Command Structure
  // ---------------------------------------------------------
  typedef struct {
    logic [31:0] awaddr;
    logic [7:0]  awlen;
    logic [2:0]  awsize;
    logic [1:0]  awburst;

    int beats_expected;
    int beats_collected;
  } aw_cmd_t;

  aw_cmd_t aw_q[$];

  // ---------------------------------------------------------
  // W Beat Structure
  // ---------------------------------------------------------
  typedef struct {
    // Data width scales with SA_SIZE
    logic [(`AIACC_PE_DATA_WIDTH * `AIACC_SA_SIZE)-1:0] wdata;
    
    // Strobe width is always Data_Width / 8
    logic [((`AIACC_PE_DATA_WIDTH * `AIACC_SA_SIZE)/8)-1:0] wstrb;
    
    logic        wlast;
  } wbeat_t;

  wbeat_t w_q[$];

  // ---------------------------------------------------------
  // Constructor
  // ---------------------------------------------------------
  function new(string name, uvm_component parent);
    super.new(name, parent);
    analysis_port = new("analysis_port", this);
  endfunction

  // ---------------------------------------------------------
  // Build Phase
  // ---------------------------------------------------------
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    if (!uvm_config_db#(hbm_agent_cfg)::get(this, "", "cfg", cfg))
      `uvm_fatal("HBM_MON", "Unable to get hbm_agent_cfg")

    vif = cfg.vif_mon;
  endfunction

  // ---------------------------------------------------------
  // Run Phase
  // ---------------------------------------------------------
  task run_phase(uvm_phase phase);
    forever begin
        collect_trans();
    end
  endtask

  function void extract_phase(uvm_phase phase);
    super.extract_phase(phase);
    // This will dump the entire associative array at the end
    dump_hbm_mem(); 
  endfunction

  // =======================================================
  //                AXI WRITE COLLECTION
  // =======================================================
  task collect_trans();
    hbm_item aw_item;
    hbm_item item;

    aw_cmd_t aw_cmd;
    wbeat_t  wbeat;

    int bytes_per_beat;
    longint unsigned beat_addr;

      @(vif.mon_cb);
      //if (!vif.rst_n) continue;

      // --------------------------------------------------
      // AW Handshake
      // --------------------------------------------------
      if (vif.mon_cb.m_axi_awvalid && vif.mon_cb.m_axi_awready) begin

        aw_cmd.awaddr = vif.mon_cb.m_axi_awaddr;
        aw_cmd.awlen  = vif.mon_cb.m_axi_awlen;
        aw_cmd.awsize = vif.mon_cb.m_axi_awsize;
        aw_cmd.awburst= vif.mon_cb.m_axi_awburst;

        aw_cmd.beats_expected  = aw_cmd.awlen + 1;
        aw_cmd.beats_collected = 0;

        // An item that only contains AW
        aw_item = hbm_item::type_id::create("aw_item", this);

        aw_item.clk      = vif.clk;
        aw_item.rst_n    = vif.rst_n;
        aw_item.aw_valid = 1;
        aw_item.aw_addr  = aw_cmd.awaddr;
        aw_item.aw_len   = aw_cmd.awlen;
        aw_item.aw_size  = aw_cmd.awsize;
        aw_item.aw_burst = aw_cmd.awburst;

        analysis_port.write(aw_item);

        aw_q.push_back(aw_cmd);
      end

      // --------------------------------------------------
      // W Handshake
      // --------------------------------------------------
      if (vif.mon_cb.m_axi_wvalid && vif.mon_cb.m_axi_wready) begin
        wbeat.wdata  = vif.mon_cb.m_axi_wdata;
        wbeat.wstrb  = vif.mon_cb.m_axi_wstrb;
        wbeat.wlast = vif.mon_cb.m_axi_wlast;

        w_q.push_back(wbeat);
      end

      // --------------------------------------------------
      // Process AW + W Pairing
      // --------------------------------------------------
      // Iterate through EVERY byte lane in the current bus width
      // This loop now scales automatically with your defines!
      if (aw_q.size() > 0) begin

        aw_cmd = aw_q[0];
        bytes_per_beat = 1 << aw_cmd.awsize;

        while ((aw_cmd.beats_collected < aw_cmd.beats_expected) && (w_q.size() > 0)) begin
          wbeat = w_q.pop_front();

          beat_addr = aw_cmd.awaddr + aw_cmd.beats_collected * bytes_per_beat;

          // Override for FIXED burst #Added Later
          if (aw_cmd.awburst == 2'b00) begin  // FIXED
            beat_addr = aw_cmd.awaddr;  // All beats go to same address
          end

          // ========================================================
          // Store into HBM Memory Model using WSTRB
          // ========================================================
          // Mask the address to the start of the bus width
          // Example: If bus is 4 bytes wide, addr 0x7 becomes 0x4
          aligned_addr = (beat_addr / NUM_BYTES) * NUM_BYTES;

          // Initialize with existing data or zeros
          if (!hbm_mem.exists(beat_addr)) begin
              hbm_mem[beat_addr] = 'h0;
          end

          // Apply strobes to the WIDE word
          for (int i = 0; i < NUM_BYTES; i++) begin
              if (wbeat.wstrb[i]) begin
                  hbm_mem[aligned_addr][i*8 +: 8] = wbeat.wdata[i*8 +: 8];
              end
          end

          // Create monitor item
          item = hbm_item::type_id::create("hbm_mon_item", this);

          item.clk    = vif.clk;
          item.rst_n  = vif.rst_n;
          item.aw_valid = 0;
          item.w_addr   = beat_addr;
          item.wdata   = wbeat.wdata;
          item.wstrb   = wbeat.wstrb;
          item.wlast  = wbeat.wlast;

          analysis_port.write(item);

          `uvm_info(get_type_name(), $sformatf({"\n\nHBM_MON WRITE EVENT:\n",
          "--------------------------------------------\n",
          " AW Command:\n",
          "   First_Aligned_addr  = 0x%0h\n",
          "   awlen               = %0d\n",
          "   awsize              = %0d  (bytes per beat = %0d)\n",
          "   awburst             = %0d\n",
          "   beats_expected      = %0d\n",
          "   beats_collected     = %0d\n",
          "\n",
          " W Beat:\n",
          "   data  = 0x%0h\n",
          "   strb  = 0x%0h\n",
          "   wlast = %0b\n",
          "\n",
          " Computed Beat:\n",
          "   beat_addr       = 0x%0h\n",
          "   beat_index      = %0d\n",
          "\n",
          " Queue Status:\n",
          "   aw_q.size() = %0d\n",
          "   w_q.size()  = %0d\n",
          "--------------------------------------------"},
          aw_cmd.awaddr,
          aw_cmd.awlen,
          aw_cmd.awsize,
          (1 << aw_cmd.awsize),
          aw_cmd.awburst,
          aw_cmd.beats_expected,
          aw_cmd.beats_collected,
          wbeat.wdata,
          wbeat.wstrb,
          wbeat.wlast,
          beat_addr,
          aw_cmd.beats_collected,
          aw_q.size(),
          w_q.size()
          ), UVM_LOW)

          aw_cmd.beats_collected++;

          if (wbeat.wlast)
            break;

        end

        // --------------------------------------------------
        // Completed Burst
        // --------------------------------------------------
        if (aw_cmd.beats_collected == aw_cmd.beats_expected) begin
          aw_q.pop_front();
        end
        else begin
          aw_q[0] = aw_cmd;
        end

      end
  endtask

  // =======================================================
  //                HBM MEMORY DUMP
  // =======================================================
  // function void dump_hbm_mem(longint unsigned start_addr = 0, longint unsigned end_addr = '1);
  //   longint unsigned addr;
  //   int count = 0;

  //   `uvm_info(get_type_name(), "---------------- FINAL HBM MEMORY DUMP ----------------", UVM_LOW)

  //   // Method 1: Iterate directly without sorting
  //   foreach (hbm_mem[addr]) begin
  //     if (addr >= start_addr && addr <= end_addr) begin
  //       `uvm_info(get_type_name(), $sformatf("HBM_MEM[0x%0h] = 0x%08h", addr, hbm_mem[addr]), UVM_LOW)
  //       count++;
  //     end
  //   end

  //   if (count == 0) begin
  //     `uvm_info(get_type_name(), "HBM_MEM is empty", UVM_LOW)
  //   end
  //   `uvm_info(get_type_name(), "---------------- END OF FINAL DUMP ----------------", UVM_LOW)
  // endfunction
  function void dump_hbm_mem(longint unsigned start_addr = 0, longint unsigned end_addr = '1);
    longint unsigned addr;
    int count = 0;
    string data_str;
    
    // Calculate widths for formatting
    localparam WIDE_WIDTH = (`AIACC_PE_DATA_WIDTH * `AIACC_SA_SIZE);
    // Number of hex characters needed for the data (4 bits per hex digit)
    localparam HEX_CHARS  = WIDE_WIDTH / 4; 
    
    `uvm_info(get_type_name(), 
      $sformatf("\n============ FINAL HBM DUMP (%0d-bit Wide Words) ============", WIDE_WIDTH), UVM_LOW)
      
    foreach (hbm_mem[addr]) begin
      if (addr >= start_addr && addr <= end_addr) begin
        // Convert to hex string WITHOUT leading zeros first
        data_str = $sformatf("%0h", hbm_mem[addr]);
        
        // Pad with zeros on the left until we reach HEX_CHARS length
        while (data_str.len() < HEX_CHARS) begin
          data_str = {"0", data_str};  // Prepend "0"
        end
        
        // Print with padded string
        `uvm_info(get_type_name(), 
          $sformatf("HBM_MEM[0x%08h] = 0x%s", addr, data_str), 
          UVM_LOW)
        count++;
      end
    end
    
    if (count == 0) begin
      `uvm_info(get_type_name(), "HBM_MEM is empty in the requested range", UVM_LOW)
    end else begin
      `uvm_info(get_type_name(), 
        $sformatf("Total %0d-bit words dumped: %0d", WIDE_WIDTH, count), UVM_LOW)
    end
    
    `uvm_info(get_type_name(), 
      "===============================================================\n", UVM_LOW)
  endfunction

endclass