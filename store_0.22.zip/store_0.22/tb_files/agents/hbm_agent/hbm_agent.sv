//============================================================
// Agent : hbm_agent
// Description : Reusable HBM Agent
//============================================================

class hbm_agent extends uvm_agent;

  `uvm_component_utils(hbm_agent)

  hbm_driver    driver;
  hbm_monitor   monitor;
  hbm_sequencer #(hbm_item) sequencer;

  hbm_agent_cfg cfg;

  // ---------------------------------------------------------
  // Constructor
  // ---------------------------------------------------------
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction


  // ---------------------------------------------------------
  // Build Phase
  // ---------------------------------------------------------
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    if (!uvm_config_db#(hbm_agent_cfg)::get(this, "", "cfg", cfg))
      `uvm_fatal("HBM_AGENT", "Cannot get hbm_agent_cfg")

    monitor = hbm_monitor::type_id::create("monitor", this);

    if (cfg.is_active == UVM_ACTIVE) begin
      driver    = hbm_driver::type_id::create("driver", this);
      sequencer = hbm_sequencer::type_id::create("sequencer", this);
    end
  endfunction


  // ---------------------------------------------------------
  // Connect Phase
  // ---------------------------------------------------------
  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);

    if (cfg.is_active == UVM_ACTIVE) begin
      driver.seq_item_port.connect(sequencer.seq_item_export);
    end
  endfunction

endclass