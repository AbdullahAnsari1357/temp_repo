//============================================================
// Sequence Item : hbm_item
// Description   : AXI Write transaction item
//============================================================

class hbm_item extends uvm_sequence_item;

  // ---------------------------------------------------------
  // Constructor
  // ---------------------------------------------------------
  function new(string name = "hbm_item");
    super.new(name);
  endfunction

  // ---------------------------------------------------------
  // Common Signals
  // ---------------------------------------------------------
  bit clk;
  bit rst_n;

  // ---------------------------------------------------------
  // W Channel info (Per Beat/ valid across all beats)
  // ---------------------------------------------------------
  bit [31:0]  w_addr; // This is not n channel AXI_signal (address for each beat)
  bit [255:0] wdata;
  bit [3:0]   wstrb;
  bit         wlast;
  bit         wvalid;

  // ---------------------------------------------------------
  // AW Channel info (Control Signals/ Valid only once per burst)
  // ---------------------------------------------------------
  bit         aw_valid;
  bit [31:0]  aw_addr;
  bit [7:0]   aw_len;
  bit [2:0]   aw_size;
  bit [1:0]   aw_burst;


  `uvm_object_utils_begin(hbm_item)
    `uvm_field_int(clk,       UVM_ALL_ON)
    `uvm_field_int(rst_n,     UVM_ALL_ON)
    `uvm_field_int(w_addr,      UVM_ALL_ON)
    `uvm_field_int(wdata,      UVM_ALL_ON)
    `uvm_field_int(wstrb,      UVM_ALL_ON)
    `uvm_field_int(wlast,     UVM_ALL_ON)
    `uvm_field_int(wvalid,    UVM_ALL_ON)
    `uvm_field_int(aw_valid,  UVM_ALL_ON)
    `uvm_field_int(aw_addr,   UVM_ALL_ON)
    `uvm_field_int(aw_len,    UVM_ALL_ON)
    `uvm_field_int(aw_size,   UVM_ALL_ON)
    `uvm_field_int(aw_burst,  UVM_ALL_ON)
  `uvm_object_utils_end

endclass