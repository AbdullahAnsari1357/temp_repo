//============================================================
// Driver : hbm_driver
// Description : AXI Slave Driver for HBM
//               Handles AW, W and Generates B Response
//============================================================

class hbm_driver extends uvm_driver #(hbm_item);

  `uvm_component_utils(hbm_driver)

  // ---------------------------------------------------------
  // Class Members/ Variables
  // ---------------------------------------------------------
  virtual hbm_if.DRV_MP vif;
  hbm_agent_cfg         cfg;
  int beats_expected;
  int beats_received;
  bit bvalid_reg;

  // ---------------------------------------------------------
  // Constructor
  // ---------------------------------------------------------
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  // ---------------------------------------------------------
  // Build Phase
  // ---------------------------------------------------------
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    if (!uvm_config_db#(hbm_agent_cfg)::get(this, "", "cfg", cfg))
      `uvm_fatal("HBM_DRV", "Unable to get hbm_agent_cfg")

    vif = cfg.vif_drv;
  endfunction

  // ---------------------------------------------------------
  // Run Phase
  // ---------------------------------------------------------
  task run_phase(uvm_phase phase);
    `uvm_info("HBM_DRV", "Driver started", UVM_LOW)
    reset_hbm_driver();
    @(vif.drv_cb);
    `uvm_info("HBM_DRV", "Reset complete, driver ready", UVM_LOW)

    beats_expected = 0;
    beats_received = 0;
    bvalid_reg = 0;
    // Always ready to accept address and data
    vif.m_axi_awready = 1'b1;
    vif.m_axi_wready  = 1'b1;

    forever begin
          @(vif.drv_cb);

      handle_axi_write();
      
    end
  endtask

  // ---------------------------------------------------------
  // Reset HBM Agent
  // ---------------------------------------------------------
  task reset_hbm_driver();
    `uvm_info("HBM_DRV", "HBM driver Reset started", UVM_LOW)

    vif.m_axi_awready         <= 1'b0;
    vif.m_axi_wready          <= 1'b0;
    vif.drv_cb.m_axi_bvalid   <= 1'b0;
    vif.drv_cb.m_axi_bresp    <= 2'b00;

    wait(vif.rst_n);
    `uvm_info("HBM_DRV", "HBM driver Reset done", UVM_LOW)
  endtask



  // =========================================================
  // AXI WRITE (SLAVE) HANDLING (Protocol Only)
  // =========================================================
  task handle_axi_write();
    //   if (!vif.rst_n)
    //     continue;

      // ----------------------------------------------------
      // AW HANDSHAKE
      // ----------------------------------------------------
      if (vif.drv_cb.m_axi_awvalid && vif.m_axi_awready) begin
        beats_expected = vif.drv_cb.m_axi_awlen + 1;
        beats_received = 0;
      end
      

      // ----------------------------------------------------
      // W HANDSHAKE
      // ----------------------------------------------------
      if (vif.drv_cb.m_axi_wvalid && vif.m_axi_wready) begin
        beats_received++;

        // If last beat OR expected beats completed
        if ((beats_received == beats_expected) && (beats_expected != 0)) begin

          bvalid_reg = 1;

          `uvm_info("HBM_DRV", $sformatf("Burst complete. Beats=%0d", beats_received), UVM_LOW)
        end
      end

      // ----------------------------------------------------
      // B CHANNEL
      // ----------------------------------------------------
      if (bvalid_reg) begin

        `uvm_info("HBM_DRV_B", "All W beats consumed → Asserting BVALID", UVM_LOW)
        vif.drv_cb.m_axi_bvalid <= 1;
        vif.drv_cb.m_axi_bresp  <= 2'b00; // OKAY

        if (vif.drv_cb.m_axi_bready) begin
          `uvm_info("HBM_DRV_B", "B handshake complete → Deasserting BVALID", UVM_LOW)
          bvalid_reg = 0;
        end
      end
      else begin
        vif.drv_cb.m_axi_bvalid <= 0;
      end

  endtask

endclass
