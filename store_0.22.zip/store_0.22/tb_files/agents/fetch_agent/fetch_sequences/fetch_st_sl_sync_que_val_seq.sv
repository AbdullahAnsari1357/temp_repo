class fetch_st_sl_sync_que_val_seq extends fetch_st_base_seq;
`uvm_object_utils(fetch_st_sl_sync_que_val_seq)
 // Class-level handle is REQUIRED for the Virtual Sequence to "see" it
  fetch_item f_item;  

  function new(string name = "fetch_st_sl_sync_que_val_seq");
    super.new(name);
  endfunction

  virtual function bit do_randomize();
    return f_item.randomize() with {
      insn.opcode           == `AIACC_OPCODE_STORE;
      insn.inst_id          == 4'h5;
      insn.mem_id           == 4'h2;
      insn.x_size           == 12'h40;
      insn.y_size           == 8'h1;
      insn.x_stride         == 16'h10;
      insn.dram_base_addr   == 48'hDEAD_0002;
      insn.sram_blk_offset  == 6'h0;
    };
  endfunction
 
  virtual task body();
    repeat(1) begin
      f_item = fetch_item::type_id::create("f_item");       
      f_item.constraint_mode(0);
      f_item.fetch_c4.constraint_mode(1);

      start_item(f_item);
      if (!do_randomize()) `uvm_error(get_type_name(), "Randomization failed")
      finish_item(f_item);

      
      `uvm_info(get_type_name(),
        $sformatf("Fetch : sent ----> tdata = 0x%0h", f_item.insn),
        UVM_LOW)
       `uvm_info(get_type_name(),
        $sformatf("\nFETCH INSTRUCTION FIELDS: OPCODE = 0x%0b SRAM_BASE_ADDRESS = 0x%0h DRAM_BASE_ADDRESS = 0x%0h X_STRIDE = 0x%0h X_SIZE = 0x%0h Y_SIZE = 0x%0h\n", 
        f_item.insn.opcode, f_item.insn.sram_blk_offset, f_item.insn.dram_base_addr, f_item.insn.x_stride, f_item.insn.x_size, f_item.insn.y_size), UVM_LOW)       
      #20ns;
    end
  endtask
endclass

class fetch_st_sl_sync_que_val_seq1 extends fetch_st_sl_sync_que_val_seq;
  `uvm_object_utils(fetch_st_sl_sync_que_val_seq1)

  function new(string name = "fetch_st_sl_sync_que_val_seq1");
    super.new(name);
  endfunction

  // Override ONLY the randomization part
  virtual function bit do_randomize();
    return f_item.randomize() with {
      insn.opcode           == `AIACC_OPCODE_STORE;
      insn.inst_id          == 4'h0;
      insn.mem_id           == 4'h2;
      insn.x_size           == 12'h40;
      insn.y_size           == 8'h1;
      insn.x_stride         == 16'h10;
      insn.dram_base_addr   == 48'hFEED_0002; // NEW ADDRESS HERE
      insn.sram_blk_offset  == 6'h0;
    };
  endfunction
endclass

class fetch_st_sl_sync_que_val_seq2 extends fetch_st_sl_sync_que_val_seq;
  `uvm_object_utils(fetch_st_sl_sync_que_val_seq2)

  function new(string name = "fetch_st_sl_sync_que_val_seq2");
    super.new(name);
  endfunction

  // Override ONLY the randomization part
  virtual function bit do_randomize();
    return f_item.randomize() with {
      insn.opcode           == `AIACC_OPCODE_STORE;
      insn.inst_id          == 4'h1;
      insn.mem_id           == 4'h2;
      insn.x_size           == 12'h40;
      insn.y_size           == 8'h1;
      insn.x_stride         == 16'h10;
      insn.dram_base_addr   == 48'hCAFE_0002; // NEW ADDRESS HERE
      insn.sram_blk_offset  == 6'h0;
    };
  endfunction
endclass

class fetch_st_sl_sync_que_val_seq3 extends fetch_st_sl_sync_que_val_seq;
  `uvm_object_utils(fetch_st_sl_sync_que_val_seq3)

  function new(string name = "fetch_st_sl_sync_que_val_seq3");
    super.new(name);
  endfunction

  // Override ONLY the randomization part
  virtual function bit do_randomize();
    return f_item.randomize() with {
      insn.opcode           == `AIACC_OPCODE_STORE;
      insn.inst_id          == 4'h2;
      insn.mem_id           == 4'h2;
      insn.x_size           == 12'h40;
      insn.y_size           == 8'h1;
      insn.x_stride         == 16'h10;
      insn.dram_base_addr   == 48'hFACE_0002; // NEW ADDRESS HERE
      insn.sram_blk_offset  == 6'h0;
    };
  endfunction
endclass

class fetch_st_sl_sync_que_val_seq4 extends fetch_st_sl_sync_que_val_seq;
  `uvm_object_utils(fetch_st_sl_sync_que_val_seq4)

  function new(string name = "fetch_st_sl_sync_que_val_seq4");
    super.new(name);
  endfunction

  // Override ONLY the randomization part
  virtual function bit do_randomize();
    return f_item.randomize() with {
      insn.opcode           == `AIACC_OPCODE_STORE;
      insn.inst_id          == 4'h3;
      insn.mem_id           == 4'h2;
      insn.x_size           == 12'h40;
      insn.y_size           == 8'h1;
      insn.x_stride         == 16'h10;
      insn.dram_base_addr   == 48'hDEED_0002; // NEW ADDRESS HERE
      insn.sram_blk_offset  == 6'h0;
    };
  endfunction
endclass
     