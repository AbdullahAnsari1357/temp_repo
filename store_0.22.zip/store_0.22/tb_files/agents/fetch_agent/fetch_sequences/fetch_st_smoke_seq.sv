class fetch_st_smoke_seq extends fetch_st_base_seq;
`uvm_object_utils(fetch_st_smoke_seq)

  function new(string name = "fetch_st_smoke_seq");
    super.new(name);
  endfunction
 
  virtual task body();
    fetch_item f_item;
    
    repeat(1) begin  
      f_item = fetch_item::type_id::create("f_item");
      f_item.constraint_mode(0);
      f_item.fetch_c4.constraint_mode(1);

      start_item(f_item);
      assert(f_item.randomize() with {
        // insn.opcode           == `AIACC_OPCODE_STORE;
        // insn.inst_id          == 4'h5;
        // insn.mem_id           == 4'h0;
        // insn.x_size           == 12'h10;
        // insn.y_size           == 8'h10;
        // insn.x_stride         == 16'h4;
        // insn.dram_base_addr   == 48'h0;
        // insn.sram_blk_offset  == 6'h0;

        // Manual assignment to match 02a40200800200000000093000400400
        insn.opcode           == 7'h1;      // (7'b0000001)
        insn.inst_id          == 4'h5;      // (4'b0101)
        insn.mem_id           == 4'h2;      // (4'b0010)
        insn.x_size           == 12'h4;     // (16 decimal)
        insn.y_size           == 8'h4;       // (1 decimal)
        insn.x_stride         == 16'h10;     // (64 decimal)
      //  insn.act_handshake    = 1'b0;      
      //  insn.empty0           = 12'h200;    

      //  insn.dram_base_addr   == 48'h09300040;
        insn.sram_blk_offset  == 6'h10;      // (6'b010000)
      //  insn.empty1           = 10'h0;
      }) 
      else 
        `uvm_error(get_type_name(), "Randomization failed")
      finish_item(f_item);

      
        `uvm_info(get_type_name(),
          $sformatf("Fetch : sent ----> tdata = 0x%0h", f_item.insn),
          UVM_LOW)
        `uvm_info(get_type_name(),
          $sformatf("\nFETCH INSTRUCTION FIELDS: OPCODE = 0x%0b SRAM_BASE_ADDRESS = 0x%0h DRAM_BASE_ADDRESS = 0x%0h X_STRIDE = 0x%0h X_SIZE = 0x%0h Y_SIZE = 0x%0h\n", 
          f_item.insn.opcode, f_item.insn.sram_blk_offset, f_item.insn.dram_base_addr, f_item.insn.x_stride, f_item.insn.x_size, f_item.insn.y_size), UVM_LOW)       
      #20ns;
    end
  endtask
endclass