class fetch_st_base_seq extends uvm_sequence #(fetch_item);

  `uvm_object_utils(fetch_st_base_seq)

  // Optional: handle to configuration
  // bram_agent_config cfg;

  function new(string name = "bram_base_seq");
    super.new(name);
  endfunction

  virtual task body();
    `uvm_info(get_type_name(), 
              "BRAM Base sequence started (does nothing by default)", 
              UVM_LOW)
  endtask

endclass