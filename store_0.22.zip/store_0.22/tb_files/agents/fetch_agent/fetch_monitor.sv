//============================================================
// Monitor : fetch_monitor
// Description : Observes DUT transactions
//============================================================

class fetch_monitor extends uvm_monitor;

  `uvm_component_utils(fetch_monitor)

  // ---------------------------------------------------------
  // Class Members
  // ---------------------------------------------------------
  virtual fetch_if.MON_MP vif;
  fetch_agent_cfg         cfg;
  fetch_item item;

  uvm_analysis_port #(fetch_item) analysis_port;

  // ---------------------------------------------------------
  // Constructor
  // ---------------------------------------------------------
  function new(string name, uvm_component parent);
    super.new(name, parent);
    analysis_port = new("analysis_port", this);
  endfunction


  // ---------------------------------------------------------
  // Build Phase
  // ---------------------------------------------------------
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    if (!uvm_config_db#(fetch_agent_cfg)::get(this, "", "cfg", cfg))
      `uvm_fatal("FETCH_MON", "Unable to get fetch_agent_cfg")

    vif = cfg.vif_mon;
  endfunction


  // ---------------------------------------------------------
  // Run Phase
  // ---------------------------------------------------------
  task run_phase(uvm_phase phase);

    forever begin
      @(vif.mon_cb);

      if (vif.mon_cb.store_queue_tvalid && vif.mon_cb.store_queue_tready) begin
        uvm_config_db#(bit)::set(null, "*", "fetch_tvalid_seen", 1);

        item = fetch_item::type_id::create("item", this);
        item.insn = vif.mon_cb.store_queue_tdata;

        analysis_port.write(item);

        `uvm_info(get_type_name(),
          $sformatf("Captured instruction = 0x%0h", item.insn),
          UVM_LOW)
      end
    end

  endtask

endclass