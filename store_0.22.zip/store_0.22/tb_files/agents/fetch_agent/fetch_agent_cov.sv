class fetch_agent_cov extends uvm_subscriber #(fetch_item);
  `uvm_component_utils(fetch_agent_cov)

  // ----------------------------------------------------------
  // Covergroup
  // ----------------------------------------------------------
  covergroup fetch_cg with function sample (fetch_item f_item);

    option.per_instance = 1;

    // ==========================================================
    // OPCODE COVERAGE
    // ==========================================================
    opcode_cp : coverpoint f_item.insn.opcode {
      bins store_opcode  = {`AIACC_OPCODE_STORE};
      // bins other_opcodes[] = {[7'h0:7'h7F]} 
                            //  with (item != `AIACC_OPCODE_STORE);
    }

    // ==========================================================
    // INSTANCE ID
    // ==========================================================
    inst_id_cp : coverpoint f_item.insn.inst_id {
      bins first_instance  = {4'h0};
      bins second_instance  = {4'h1};
      bins third_instance  = {4'h2};
      bins fourth_instance  = {4'h3};
      bins all_instances   = {4'h5};
    }

    // ==========================================================
    // MEMORY ID
    // ==========================================================
    mem_id_cp : coverpoint f_item.insn.mem_id {
      bins out_bram = {4'h0};
      bins other_mem[] = {[4'h1:4'hF]};
    }

    // ==========================================================
    // X SIZE COVERAGE
    // ==========================================================
    x_size_cp : coverpoint f_item.insn.x_size {
      bins block_size   = {`AIACC_BLOCK_SIZE};
      bins low        = {[0:15]};
      bins mid       = {[16:255]};
      bins high        = {[256:12'hFFF]};
    }

    // ==========================================================
    // Y SIZE COVERAGE
    // ==========================================================
    y_size_cp : coverpoint f_item.insn.y_size {
      bins sa_size   = {`AIACC_SA_SIZE};
      bins low     = {[0:15]};
      bins mid    = {[16:127]};
      bins max_val   = {8'hFF};
    }

    // ==========================================================
    // STRIDE COVERAGE
    // ==========================================================
    x_stride_cp : coverpoint f_item.insn.x_stride {
      bins block_size  = {`AIACC_BLOCK_SIZE};
      bins low       = {[0:64]};
      bins high       = {[65:16'hFFFF]};
    }

    // ==========================================================
    // DRAM ADDRESS COVERAGE (partitioned)
    // ==========================================================
    dram_addr_cp : coverpoint f_item.insn.dram_base_addr {
      bins low_addr    = {[48'h0 : 48'h0FFF_FFFF]};
      bins high_addr   = {[48'h1000_0000 : 48'hFFFF_FFFF_FFFF]};
    }

    // ==========================================================
    // SRAM BLOCK OFFSET (Ping-Pong important)
    // ==========================================================
    sram_blk_cp : coverpoint f_item.insn.sram_blk_offset {
      bins zero_blk_offset    = {0};
      bins nonzero_blk_offset   = {[6'h1 : 6'h3F]};
    }

    // ==========================================================
    // ACT HANDSHAKE
    // ==========================================================
    act_hs_cp : coverpoint f_item.insn.act_handshake {
      bins act    = {0};
    }

    // ==========================================================
    // IMPORTANT CROSSES
    // ==========================================================

    // Memory Selection × instance selection × leaving offset 
    mem_x_inst : cross mem_id_cp, inst_id_cp;

    // Size relationship
    xsize_x_ysize : cross x_size_cp, y_size_cp;

  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    fetch_cg = new();
  endfunction : new

  virtual function void write(fetch_item t);
    fetch_cg.sample(t);
  endfunction

  function void report_phase(uvm_phase phase);
  super.report_phase(phase);
  `uvm_info("COV_REPORT", $sformatf("Fetch Coverage: %0.2f%%", fetch_cg.get_inst_coverage()), UVM_LOW)
endfunction  
endclass

