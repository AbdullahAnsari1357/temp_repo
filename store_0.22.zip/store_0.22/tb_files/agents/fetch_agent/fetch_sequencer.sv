//============================================================
// Sequencer : fetch_sequencer
//============================================================

class fetch_sequencer extends uvm_sequencer #(fetch_item);

  `uvm_component_utils(fetch_sequencer)

  // ---------------------------------------------------------
  // Constructor
  // ---------------------------------------------------------
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

endclass