typedef struct packed {
    logic [`AIACC_OPCODE_BIT_WIDTH-1:0] opcode;//7
    logic [`AIACC_INST_ID_WIDTH-1:0]   inst_id;//4 //selects which compute instance's BRAM to fetch data from
	  logic [`AIACC_MEM_ID_WIDTH-1:0]    mem_id;//4 // 0 is for out_bram
    logic [`AIACC_X_SIZE_WIDTH-1:0]    x_size;//12 -> 16, 32,48 in 0.2 , 16 bytes
    logic [`AIACC_Y_SIZE_WIDTH-1:0]    y_size;//8
    logic [`AIACC_X_STRIDE_WIDTH-1:0]  x_stride;//16
    logic act_handshake ;//1
    logic [`AIACC_STORE_UNUSED0_WIDTH-1:0] empty0;//12
	
	// 64 bit boundary
    logic [`AIACC_DRAM_ADDR_WIDTH-1:0] dram_base_addr;//48
    logic [`AIACC_SRAM_OFFSET_WIDTH-1:0] sram_blk_offset;//6
    logic [`AIACC_STORE_UNUSED1_WIDTH-1:0] empty1;//10
} store_insn_t;

class fetch_item extends uvm_sequence_item;

  function new(string name = "fetch_item");
    super.new(name);
  endfunction

  rand store_insn_t insn;

  // --------------------------------------------------
  // Fixed instruction constraint
  // --------------------------------------------------
  constraint fetch_c1 {
    insn.opcode           == 7'h1;
    insn.inst_id          == 4'h5;
    insn.mem_id           == 4'h0;
    insn.x_size           == 12'h4;
    insn.y_size           == 8'h4;
    insn.x_stride         == 16'h10;
    insn.act_handshake    == 1'h0;
    insn.empty0           == 12'h0;
    insn.dram_base_addr   == 48'h0;
    insn.sram_blk_offset  == 6'h0;
    insn.empty1           == 10'h0;
  }

constraint fetch_c2 {
       insn.inst_id          inside {[4'h0 : 4'hF]};
       insn.mem_id           inside {[4'h0 : 4'hF]};

       insn.opcode           == `AIACC_OPCODE_STORE; 
       insn.x_size           == `AIACC_BLOCK_SIZE;
       insn.y_size           == `AIACC_SA_SIZE;
       insn.x_stride         == `AIACC_BLOCK_SIZE;

       insn.dram_base_addr   inside {[48'h0 : 48'hFFFF_FFFF_FFFF]};
       insn.sram_blk_offset  inside {[6'h0 : 6'h3F]};
       
       insn.act_handshake    == 1'h0;
       insn.empty0           == 12'h0;
       insn.empty1           == 10'h0;
}


  // --------------------------------------------------
  // Random instruction (random)
  // --------------------------------------------------
constraint fetch_c3 {
       insn.inst_id          inside {[4'h0 : 4'hF]};
       insn.mem_id           inside {[4'h0 : 4'hF]};
       
       insn.opcode           == `AIACC_OPCODE_STORE;
       insn.x_size           inside {[12'h0 : 12'hFFF]};
       insn.y_size           inside {[8'h0 : 8'hFF]};
       insn.x_stride         inside {[16'h0 : 16'hFFFF]};

       insn.dram_base_addr   inside {[48'h0 : 48'hFFFF_FFFF_FFFF]};
       insn.sram_blk_offset  inside {[6'h0 : 6'h3F]} ;
       
       insn.act_handshake    == 1'h0;
       insn.empty0           == 12'h0;
       insn.empty1           == 10'h0;
}

constraint fetch_c4 {
       insn.inst_id          inside {[4'h0 : 4'hF]};
       insn.mem_id           inside {[4'h0 : 4'hF]};
       
       insn.opcode           inside {[7'h0 : 7'h7F]};
       insn.x_size           inside {[12'h0 : 12'hFFF]};
       insn.y_size           inside {[8'h0 : 8'hFF]};
       insn.x_stride         inside {[16'h0 : 16'hFFFF]};

       insn.dram_base_addr   inside {[48'h0 : 48'hFFFF_FFFF_FFFF]};
       insn.sram_blk_offset  inside {[6'h0 : 6'h3F]} ;
       
       insn.act_handshake    == 1'h0;
       insn.empty0           == 12'h0;
       insn.empty1           == 10'h0;
}

  `uvm_object_utils_begin(fetch_item)
   `uvm_field_sarray_int(insn, UVM_ALL_ON)
  `uvm_object_utils_end
endclass
