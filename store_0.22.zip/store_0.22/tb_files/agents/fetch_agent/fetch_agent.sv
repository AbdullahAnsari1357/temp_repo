//============================================================
// Agent : fetch_agent
// Description : Reusable fetch UVM agent
//============================================================

class fetch_agent extends uvm_agent;

  `uvm_component_utils(fetch_agent)

  // ---------------------------------------------------------
  // Components
  // ---------------------------------------------------------
  fetch_driver    driver;
  fetch_monitor   monitor;
  fetch_sequencer #(fetch_item) sequencer;

  fetch_agent_cfg cfg;
  fetch_agent_cov cov;

  // ---------------------------------------------------------
  // Constructor
  // ---------------------------------------------------------
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction


  // ---------------------------------------------------------
  // Build Phase
  // ---------------------------------------------------------
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    if (!uvm_config_db#(fetch_agent_cfg)::get(this, "", "cfg", cfg))
      `uvm_fatal("FETCH_AGENT", "Unable to get fetch_agent_cfg")

    // Monitor always created
    monitor = fetch_monitor::type_id::create("monitor", this);
    cov = fetch_agent_cov::type_id::create("cov", this);

    // Driver + Sequencer only if ACTIVE
    if (cfg.is_active == UVM_ACTIVE) begin
      driver    = fetch_driver::type_id::create("driver", this);
      sequencer = fetch_sequencer::type_id::create("sequencer", this);
    end
  endfunction


  // ---------------------------------------------------------
  // Connect Phase
  // ---------------------------------------------------------
  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);

    if (cfg.is_active == UVM_ACTIVE) begin
      driver.seq_item_port.connect(sequencer.seq_item_export);
    end
    monitor.analysis_port.connect(cov.analysis_export);
  endfunction

endclass