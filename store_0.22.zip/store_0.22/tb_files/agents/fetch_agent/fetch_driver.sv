//============================================================
// Driver : fetch_driver
// Description : Drives transactions to DUT
//============================================================

class fetch_driver extends uvm_driver #(fetch_item);

  `uvm_component_utils(fetch_driver)

  // ---------------------------------------------------------
  // Class Members
  // ---------------------------------------------------------
  virtual fetch_if.DRV_MP vif;
  fetch_agent_cfg      cfg;
  fetch_item           f_item;

  // ---------------------------------------------------------
  // Constructor
  // ---------------------------------------------------------
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction


  // ---------------------------------------------------------
  // Build Phase
  // ---------------------------------------------------------
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    if (!uvm_config_db#(fetch_agent_cfg)::get(this, "", "cfg", cfg))
      `uvm_fatal("FETCH_DRV", "Unable to get fetch_agent_cfg")

    vif = cfg.vif_drv;
  endfunction

  // ---------------------------------------------------------
  // Run Phase
  // ---------------------------------------------------------
  task run_phase(uvm_phase phase);
    `uvm_info("FETCH_DRV", "Driver started", UVM_LOW)
    reset_fetch_driver();
    @(vif.drv_cb);
    `uvm_info("FETCH_DRV", "Reset complete, driver ready", UVM_LOW)
    forever begin
      seq_item_port.get_next_item(f_item);

      fork
      begin : DRIVE_THREAD
        drive_transfer(f_item);
        seq_item_port.item_done();
      end

      begin : RESET_WATCHDOG
        wait (vif.rst_n == 0);
      end
      join_any

      disable fork;
      if (!vif.rst_n) begin
        `uvm_info("FETCH_DRV", "Reset detected during transaction", UVM_LOW)
        handle_reset();
      end
    end
  endtask

  // ---------------------------------------------------------
  // Reset FETCH Agent
  // ---------------------------------------------------------
  task reset_fetch_driver();
    `uvm_info("FETCH_DRV", "Fetch driver Reset started", UVM_LOW)

    vif.drv_cb.store_queue_tvalid <= 1'b0;
    vif.drv_cb.store_queue_tdata  <= '0;

    wait(vif.rst_n);
    `uvm_info("FETCH_DRV", "Fetch driver Reset done", UVM_LOW)
  endtask


  // ---------------------------------------------------------
  // Drive Task
  // ---------------------------------------------------------
  task drive_transfer(fetch_item item);

    `uvm_info(get_type_name(),
      $sformatf("Driving instruction = 0x%0h", item.insn),
      UVM_LOW)

    vif.drv_cb.store_queue_tdata  <= item.insn;
    vif.drv_cb.store_queue_tvalid <= 1'b1;

    // Wait for handshake OR reset
    while (vif.rst_n && !vif.drv_cb.store_queue_tready)
      @(vif.drv_cb);

    if (!vif.rst_n)
      return;  // Exit immediately if reset hit

    @(vif.drv_cb);
    vif.drv_cb.store_queue_tvalid <= 1'b0;

    `uvm_info(get_type_name(),
        $sformatf("Transaction complete: 0x%0h", item.insn),
        UVM_LOW)
  endtask

  // ---------------------------------------------------------
  // Reset Task
  // ---------------------------------------------------------
  task handle_reset();
    // Immediately drive safe values
    vif.drv_cb.store_queue_tvalid <= 1'b0;
    vif.drv_cb.store_queue_tdata  <= '0;

    // Wait for reset release
    wait (vif.rst_n == 1);
    @(vif.drv_cb);

    `uvm_info("FETCH_DRV", "Reset recovery complete", UVM_LOW)
  endtask

endclass