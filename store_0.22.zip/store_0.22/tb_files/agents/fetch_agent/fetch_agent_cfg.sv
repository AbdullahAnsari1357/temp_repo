//============================================================
// Configuration : fetch_agent_cfg
// Description   : Configuration object for fetch agent
//============================================================

class fetch_agent_cfg extends uvm_object;

  `uvm_object_utils(fetch_agent_cfg)

  // ---------------------------------------------------------
  // Configuration Fields
  // ---------------------------------------------------------
  uvm_active_passive_enum is_active = UVM_ACTIVE;

  virtual fetch_if.DRV_MP vif_drv;
  virtual fetch_if.MON_MP vif_mon;

  // ---------------------------------------------------------
  // Constructor
  // ---------------------------------------------------------
  function new(string name = "fetch_agent_cfg");
    super.new(name);
  endfunction

endclass