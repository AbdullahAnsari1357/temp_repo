class bram_agent_cov extends uvm_subscriber #(bram_item);
  `uvm_component_utils(bram_agent_cov)

  // ----------------------------------------------------------
  // Covergroup
  // ----------------------------------------------------------
  covergroup bram_cg with function sample (bram_item b_item);
    option.per_instance = 1;

    // ==========================================================
    // 1. SYNC QUEUE COVERAGE
    // Tracks which queues were activated via the mask
    // ==========================================================
    sync_mask_cp : coverpoint b_item.sync_valid_mask {
      bins all_off    = {4'b0000};
      bins single_q0  = {4'b0001};
      bins single_q1  = {4'b0010};
      bins single_q2  = {4'b0100};
      bins single_q3  = {4'b1000};
      bins all_on     = {4'b1111};
    }

    // ==========================================================
    // 2. BRAM ADDRESS COVERAGE 
    // BRAM is an array, track the range of addresses accessed
    // ==========================================================
    addr_accessed_cp : coverpoint b_item.out_mem_addr {
      bins low_range   = {[0:63]};
      bins mid_range   = {[64:255]};
      bins high_range  = {[256:1024]}; //To be adjusted based on BRAM size      
    }

    // ==========================================================
    // 3. BRAM S_AXIS HANDSHAKE COVERAGE
    // Tracks the valid/ready toggles and handshakes happening
    // ==========================================================
    valid_q0_toggle_cp : coverpoint b_item.s_axis_sync_q_0_tvalid {
      bins deasserted = {1'b0};
      bins asserted   = {1'b1};
    }
    valid_q1_toggle_cp : coverpoint b_item.s_axis_sync_q_1_tvalid {
      bins deasserted = {1'b0};
      bins asserted   = {1'b1};
    }
    valid_q2_toggle_cp : coverpoint b_item.s_axis_sync_q_2_tvalid {
      bins deasserted = {1'b0};
      bins asserted   = {1'b1};
    }
    valid_q3_toggle_cp : coverpoint b_item.s_axis_sync_q_3_tvalid {
      bins deasserted = {1'b0};
      bins asserted   = {1'b1};
    }


    ready_q0_toggle_cp : coverpoint b_item.s_axis_sync_q_0_tready {
      bins busy  = {1'b0};
      bins ready = {1'b1};
    }
    ready_q1_toggle_cp : coverpoint b_item.s_axis_sync_q_1_tready {
      bins busy  = {1'b0};
      bins ready = {1'b1};
    }
    ready_q2_toggle_cp : coverpoint b_item.s_axis_sync_q_2_tready {
      bins busy  = {1'b0};
      bins ready = {1'b1};
    }
    ready_q3_toggle_cp : coverpoint b_item.s_axis_sync_q_3_tready {
      bins busy  = {1'b0};
      bins ready = {1'b1};
    }

    // Handshake for Queue 0
    hs_q0_cross : cross valid_q0_toggle_cp, ready_q0_toggle_cp {
      bins success = binsof(valid_q0_toggle_cp.asserted) && binsof(ready_q0_toggle_cp.ready);
      //Ignore all other bins created by automatic combinations (!(A&&B) = (!A||!B))
      ignore_bins others = !binsof(valid_q0_toggle_cp.asserted) || !binsof(ready_q0_toggle_cp.ready);
    }

    // Handshake for Queue 1
    hs_q1_cross : cross valid_q1_toggle_cp, ready_q1_toggle_cp {
      bins success = binsof(valid_q1_toggle_cp.asserted) && binsof(ready_q1_toggle_cp.ready);
      //Ignore all other bins created by automatic combinations (!(A&&B) = (!A||!B))
      ignore_bins others = !binsof(valid_q1_toggle_cp.asserted) || !binsof(ready_q1_toggle_cp.ready);
    }

    // Handshake for Queue 2
    hs_q2_cross : cross valid_q2_toggle_cp, ready_q2_toggle_cp {
      bins success = binsof(valid_q2_toggle_cp.asserted) && binsof(ready_q2_toggle_cp.ready);
      //Ignore all other bins created by automatic combinations (!(A&&B) = (!A||!B))
      ignore_bins others = !binsof(valid_q2_toggle_cp.asserted) || !binsof(ready_q2_toggle_cp.ready);
    }

    // Handshake for Queue 3
    hs_q3_cross : cross valid_q3_toggle_cp, ready_q3_toggle_cp {
      bins success = binsof(valid_q3_toggle_cp.asserted) && binsof(ready_q3_toggle_cp.ready);
      //Ignore all other bins created by automatic combinations (!(A&&B) = (!A||!B))
      ignore_bins others = !binsof(valid_q3_toggle_cp.asserted) || !binsof(ready_q3_toggle_cp.ready);
    }


    // ==========================================================
    // 4. BRAM S2G HANDSHAKE COVERAGE
    // Tracks the valid/ready toggles and handshakes happening
    // ==========================================================
    s2g_valid_queue0_toggle_cp : coverpoint b_item.s2g_sync_queue_0_tvalid {
      bins deasserted = {1'b0};
      bins asserted   = {1'b1};
    }
    s2g_valid_queue1_toggle_cp : coverpoint b_item.s2g_sync_queue_1_tvalid {
      bins deasserted = {1'b0};
      bins asserted   = {1'b1};
    }
    s2g_valid_queue2_toggle_cp : coverpoint b_item.s2g_sync_queue_2_tvalid {
      bins deasserted = {1'b0};
      bins asserted   = {1'b1};
    }
    s2g_valid_queue3_toggle_cp : coverpoint b_item.s2g_sync_queue_3_tvalid {
      bins deasserted = {1'b0};
      bins asserted   = {1'b1};
    }


    s2g_ready_queue0_toggle_cp : coverpoint b_item.s2g_sync_queue_0_tready {
      bins busy  = {1'b0};
      bins ready = {1'b1};
    }
    s2g_ready_queue1_toggle_cp : coverpoint b_item.s2g_sync_queue_1_tready {
      bins busy  = {1'b0};
      bins ready = {1'b1};
    }
    s2g_ready_queue2_toggle_cp : coverpoint b_item.s2g_sync_queue_2_tready {
      bins busy  = {1'b0};
      bins ready = {1'b1};
    }
    s2g_ready_queue3_toggle_cp : coverpoint b_item.s2g_sync_queue_3_tready {
      bins busy  = {1'b0};
      bins ready = {1'b1};
    }

    // Handshake for Queue 0
    s2g_hs_queue0_cross : cross s2g_valid_queue0_toggle_cp, s2g_ready_queue0_toggle_cp {
      bins success = binsof(s2g_valid_queue0_toggle_cp.asserted) && binsof(s2g_ready_queue0_toggle_cp.ready);
      //Ignore all other bins created by automatic combinations (!(A&&B) = (!A||!B))
      ignore_bins others = !binsof(s2g_valid_queue0_toggle_cp.asserted) || !binsof(s2g_ready_queue0_toggle_cp.ready);
    }

    // Handshake for Queue 1
    s2g_hs_queue1_cross : cross s2g_valid_queue1_toggle_cp, s2g_ready_queue1_toggle_cp {
      bins success = binsof(s2g_valid_queue1_toggle_cp.asserted) && binsof(s2g_ready_queue1_toggle_cp.ready);
      //Ignore all other bins created by automatic combinations (!(A&&B) = (!A||!B))
      ignore_bins others = !binsof(s2g_valid_queue1_toggle_cp.asserted) || !binsof(s2g_ready_queue1_toggle_cp.ready);
    }

    // Handshake for Queue 2
    s2g_hs_queue2_cross : cross s2g_valid_queue2_toggle_cp, s2g_ready_queue2_toggle_cp {
      bins success = binsof(s2g_valid_queue2_toggle_cp.asserted) && binsof(s2g_ready_queue2_toggle_cp.ready);
      //Ignore all other bins created by automatic combinations (!(A&&B) = (!A||!B))
      ignore_bins others = !binsof(s2g_valid_queue2_toggle_cp.asserted) || !binsof(s2g_ready_queue2_toggle_cp.ready);
    }

    // Handshake for Queue 3
    s2g_hs_queue3_cross : cross s2g_valid_queue3_toggle_cp, s2g_ready_queue3_toggle_cp {
      bins success = binsof(s2g_valid_queue3_toggle_cp.asserted) && binsof(s2g_ready_queue3_toggle_cp.ready);
      //Ignore all other bins created by automatic combinations (!(A&&B) = (!A||!B))
      ignore_bins others = !binsof(s2g_valid_queue3_toggle_cp.asserted) || !binsof(s2g_ready_queue3_toggle_cp.ready);
    }

    // ==========================================================
    // 5. OTHER IMPORTANT CROSSES
    // ==========================================================
    
    // Ensure we have read from different addresses using different sync configurations
    mask_x_addr : cross sync_mask_cp, addr_accessed_cp;

  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    bram_cg = new();
  endfunction : new

  virtual function void write(bram_item t);
    bram_cg.sample(t);
  endfunction

  function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("COV_REPORT", $sformatf("Bram Coverage: %0.2f%%", bram_cg.get_inst_coverage()), UVM_LOW)
  endfunction  
endclass