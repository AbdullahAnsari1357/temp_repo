//============================================================
// Monitor : bram_monitor
// Description : Observes BRAM read transactions
//============================================================

class bram_monitor extends uvm_monitor;

  `uvm_component_utils(bram_monitor)

  virtual bram_if.MON_MP vif;
  bram_agent_cfg        cfg;

  uvm_analysis_port #(bram_item) data_port;
  uvm_analysis_port #(bram_item) cov_port;
  bram_item item;

  // ---------------------------------------------------------
  // Constructor
  // ---------------------------------------------------------
  function new(string name, uvm_component parent);
    super.new(name, parent);
    data_port = new("data_port", this);
    cov_port = new("cov_port", this);
  endfunction


  // ---------------------------------------------------------
  // Build Phase
  // ---------------------------------------------------------
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    if (!uvm_config_db#(bram_agent_cfg)::get(this, "", "cfg", cfg))
      `uvm_fatal("BRAM_MON", "Cannot get bram_agent_cfg")

    vif = cfg.vif_mon;
  endfunction


  // ---------------------------------------------------------
  // Run Phase
  // ---------------------------------------------------------
  task run_phase(uvm_phase phase);
    forever begin
      @(vif.mon_cb);
      item = bram_item::type_id::create("bram_read", this);
      item.s_axis_sync_q_0_tvalid = vif.mon_cb.s_axis_sync_q_0_tvalid;
      item.s_axis_sync_q_0_tready = vif.mon_cb.s_axis_sync_q_0_tready;
      item.s_axis_sync_q_1_tvalid = vif.mon_cb.s_axis_sync_q_1_tvalid;
      item.s_axis_sync_q_1_tready = vif.mon_cb.s_axis_sync_q_1_tready;
      item.s_axis_sync_q_2_tvalid = vif.mon_cb.s_axis_sync_q_2_tvalid;
      item.s_axis_sync_q_2_tready = vif.mon_cb.s_axis_sync_q_2_tready;
      item.s_axis_sync_q_3_tvalid = vif.mon_cb.s_axis_sync_q_3_tvalid;
      item.s_axis_sync_q_3_tready = vif.mon_cb.s_axis_sync_q_3_tready;

      item.s2g_sync_queue_0_tvalid = vif.mon_cb.s2g_sync_queue_0_tvalid;
      item.s2g_sync_queue_0_tready = vif.mon_cb.s2g_sync_queue_0_tready;
      item.s2g_sync_queue_1_tvalid = vif.mon_cb.s2g_sync_queue_1_tvalid;
      item.s2g_sync_queue_1_tready = vif.mon_cb.s2g_sync_queue_1_tready;
      item.s2g_sync_queue_2_tvalid = vif.mon_cb.s2g_sync_queue_2_tvalid;
      item.s2g_sync_queue_2_tready = vif.mon_cb.s2g_sync_queue_2_tready;
      item.s2g_sync_queue_3_tvalid = vif.mon_cb.s2g_sync_queue_3_tvalid;
      item.s2g_sync_queue_3_tready = vif.mon_cb.s2g_sync_queue_3_tready;
 
      if (vif.mon_cb.out_mem_en_a && !vif.mon_cb.out_mem_wen_a) begin
        item.clk           = vif.clk;
        item.rst_n         = vif.rst_n;
        item.out_mem_en    = vif.mon_cb.out_mem_en_a;
        item.out_mem_addr  = vif.mon_cb.out_mem_addr_a;

        // Adding one cycle delay to capture correct data as the data is assigned to out_mem_din_a 1 cycle after the out_mem_addr_a
        @(vif.mon_cb);

        item.out_mem_rdata = vif.mon_cb.out_mem_din_a; // REAL DATA
        item.read_valid    = 1;

        `uvm_info(get_type_name(), 
         $sformatf("\n\nBRAM_MON: READ BRAM_ADDR = %0d, BRAM_DATA = %0h en=%0b ", 
         item.out_mem_addr, item.out_mem_rdata, item.out_mem_en), UVM_LOW);
         data_port.write(item);
      end
      cov_port.write(item);
    end

  endtask

endclass