//============================================================
// Sequence Item : bram_item
// Description   : BRAM memory + sync configuration
//============================================================

class bram_item extends uvm_sequence_item;

  // ---------------------------------------------------------
  // Constructor
  // ---------------------------------------------------------
  function new(string name = "bram_item");
    super.new(name);
  endfunction
  

  //DUT signals
  bit clk;
  bit rst_n;
  bit out_mem_en;
  bit [`AIACC_INP_BRAM_ADDR_WIDTH-1:0] out_mem_addr;
  bit [(`AIACC_PE_DATA_WIDTH * `AIACC_SA_SIZE)-1:0] out_mem_rdata;  // <-- ACTUAL DUT DATA
  bit read_valid;

  // 4 queues
  rand bit [3:0] sync_valid_mask;
  rand bit [3:0] s2g_sync_ready_mask;
  bit s_axis_sync_q_0_tvalid;
  bit s_axis_sync_q_0_tready;
  bit s_axis_sync_q_1_tvalid;
  bit s_axis_sync_q_1_tready;
  bit s_axis_sync_q_2_tvalid;
  bit s_axis_sync_q_2_tready;
  bit s_axis_sync_q_3_tvalid;
  bit s_axis_sync_q_3_tready;

  bit s2g_sync_queue_0_tvalid;
  bit s2g_sync_queue_0_tready;
  bit s2g_sync_queue_1_tvalid;
  bit s2g_sync_queue_1_tready;
  bit s2g_sync_queue_2_tvalid;
  bit s2g_sync_queue_2_tready;
  bit s2g_sync_queue_3_tvalid;
  bit s2g_sync_queue_3_tready;

  

  // BRAM memory
  localparam BRAM_DATA_WIDTH = (`AIACC_PE_DATA_WIDTH * `AIACC_SA_SIZE);
  localparam BRAM_DEPTH      = (1 << `AIACC_INP_BRAM_ADDR_WIDTH);

  rand bit [BRAM_DATA_WIDTH-1:0] bram [BRAM_DEPTH];// changes from 2^16 to 2^6, 2^4(ooa test)

  // At least one queue must be high
  constraint n_valid_c {
    sync_valid_mask != 4'b0000;
  }

  // -------------------------
  // Fixed pattern constraint
  // -------------------------
  constraint bram_fixed_c {
    bram[0]  == {(BRAM_DATA_WIDTH/4){4'h0}};
    bram[1]  == {(BRAM_DATA_WIDTH/4){4'h1}};
    bram[2]  == {(BRAM_DATA_WIDTH/4){4'h2}};
    bram[3]  == {(BRAM_DATA_WIDTH/4){4'h3}};
    bram[4]  == {(BRAM_DATA_WIDTH/4){4'h4}};
    bram[5]  == {(BRAM_DATA_WIDTH/4){4'h5}};
    bram[6]  == {(BRAM_DATA_WIDTH/4){4'h6}};
    bram[7]  == {(BRAM_DATA_WIDTH/4){4'h7}};
    bram[8]  == {(BRAM_DATA_WIDTH/4){4'h8}};
    bram[9]  == {(BRAM_DATA_WIDTH/4){4'h9}};
    bram[10]  == {(BRAM_DATA_WIDTH/4){4'hA}};
    bram[11]  == {(BRAM_DATA_WIDTH/4){4'hB}};
    bram[12]  == {(BRAM_DATA_WIDTH/4){4'hC}};
    bram[13]  == {(BRAM_DATA_WIDTH/4){4'hD}};
    bram[14]  == {(BRAM_DATA_WIDTH/4){4'hE}};
    bram[15]  == {(BRAM_DATA_WIDTH/4){4'hF}};
  }

  // -------------------------
  // Random data constraint
  // -------------------------
  constraint bram_random_c {
  foreach (bram[i]) {
    // This scales automatically regardless of WIDE_WIDTH
    bram[i] inside {[ '0 : '1 ]}; 
  }
  }

  // -------------------------
  // Data pattern constraint
  // -------------------------
  constraint bram_pattern_c {
  foreach (bram[i]) {
    bram[i] == ( (BRAM_DATA_WIDTH'(16'hCAFE) << (BRAM_DATA_WIDTH-16)) | i );
  }
  }

  `uvm_object_utils_begin(bram_item)
    `uvm_field_int(clk,           UVM_ALL_ON)
    `uvm_field_int(rst_n,         UVM_ALL_ON)
    `uvm_field_int(out_mem_en,    UVM_ALL_ON)
    `uvm_field_int(out_mem_addr,  UVM_ALL_ON)
    `uvm_field_int(out_mem_rdata, UVM_ALL_ON)
    `uvm_field_int(sync_valid_mask, UVM_ALL_ON)
    `uvm_field_int(s2g_sync_ready_mask, UVM_ALL_ON)
    `uvm_field_sarray_int(bram, UVM_ALL_ON)
  `uvm_object_utils_end

endclass