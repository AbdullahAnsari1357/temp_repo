//============================================================
// Configuration : bram_agent_cfg
//============================================================

class bram_agent_cfg extends uvm_object;

  `uvm_object_utils(bram_agent_cfg)

  uvm_active_passive_enum is_active = UVM_ACTIVE;

  virtual bram_if.DRV_MP vif_drv;
  virtual bram_if.MON_MP vif_mon;

  function new(string name = "bram_agent_cfg");
    super.new(name);
  endfunction

endclass