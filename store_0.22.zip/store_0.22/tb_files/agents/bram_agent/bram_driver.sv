//============================================================
// Driver : bram_driver
// Description : Drives sync queues and BRAM read responses
//============================================================

class bram_driver extends uvm_driver #(bram_item);

  `uvm_component_utils(bram_driver)

  // ---------------------------------------------------------
  // Members
  // ---------------------------------------------------------
  virtual bram_if.DRV_MP vif;
  bram_agent_cfg        cfg;
  bram_item             b_item;
  bram_item             current_bram;
  bit background_started;
  bit fetch_tvalid_seen;
  event sync_handshake_done;

  // ---------------------------------------------------------
  // Constructor
  // ---------------------------------------------------------
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction


  // ---------------------------------------------------------
  // Build Phase
  // ---------------------------------------------------------
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    if (!uvm_config_db#(bram_agent_cfg)::get(this, "", "cfg", cfg))
      `uvm_fatal("BRAM_DRV", "Cannot get bram_agent_cfg")

    if (cfg.vif_drv == null)
      `uvm_fatal("BRAM_DRV", "Virtual Interface (vif_drv) is NULL in config!")

    vif = cfg.vif_drv;
  endfunction

 
  // ---------------------------------------------------------
  // Run Phase
  // ---------------------------------------------------------
  task run_phase(uvm_phase phase);
    `uvm_info("BRAM_DRV", "Driver started", UVM_LOW)
    reset_bram_driver();
    // @(vif.drv_cb);
    `uvm_info("BRAM_DRV", "Reset complete, driver ready", UVM_LOW)
    background_started = 0;
    forever begin
      seq_item_port.get_next_item(b_item);
      current_bram = bram_item::type_id::create("current_bram");
      current_bram.copy(b_item);
      `uvm_info(get_type_name(), 
        $sformatf("BRAM_DRV: Received Bram item from sequencer - bram[0]=%0h bram[1]=%0h bram[2]=%0h", 
        current_bram.bram[0], current_bram.bram[1], current_bram.bram[2]),
        UVM_LOW)
      if (!background_started) begin
          background_started = 1;
        fork
            drive_sync_queues(); // Drives incoming sync queues
            drive_s2g_sync_queues();  // Drives s2g ready signals
            drive_bram_reads();
            `uvm_info(get_type_name(), "BRAM Driver--> Ceated sync_queues and bram_reads threads", UVM_LOW);
        join_none
      end
      //@(sync_handshake_done);
      //repeat(150) @(vif.drv_cb);
      repeat(10) @(vif.drv_cb);
      seq_item_port.item_done();
    end
  endtask

  // ---------------------------------------------------------
  // Reset BRAM Agent
  // ---------------------------------------------------------
  task reset_bram_driver();
    `uvm_info("BRAM_DRV", "BRAM driver Reset started", UVM_LOW)

    vif.drv_cb.s_axis_sync_q_0_tvalid <= 1'b0;
    vif.drv_cb.s_axis_sync_q_1_tvalid <= 1'b0;
    vif.drv_cb.s_axis_sync_q_2_tvalid <= 1'b0;
    vif.drv_cb.s_axis_sync_q_3_tvalid <= 1'b0;

    vif.drv_cb.s_axis_sync_q_0_tdata <= 'h0;
    vif.drv_cb.s_axis_sync_q_1_tdata <= 'h0;
    vif.drv_cb.s_axis_sync_q_2_tdata <= 'h0;
    vif.drv_cb.s_axis_sync_q_3_tdata <= 'h0;

    vif.drv_cb.s2g_sync_queue_0_tready <= 1'b1;
    vif.drv_cb.s2g_sync_queue_1_tready <= 1'b1;
    vif.drv_cb.s2g_sync_queue_2_tready <= 1'b1;
    vif.drv_cb.s2g_sync_queue_3_tready <= 1'b1;

    vif.drv_cb.out_mem_din_a <= '0;

    wait(vif.rst_n);
    `uvm_info("BRAM_DRV", "BRAM driver Reset done", UVM_LOW)
  endtask


  // ---------------------------------------------------------
  // Drive Sync Queues
  // ---------------------------------------------------------

  task drive_sync_queues();
    forever begin
      fetch_tvalid_seen = 0;
      wait(current_bram != null); // Wait until an item is actually received
      @(vif.drv_cb);

      vif.drv_cb.s_axis_sync_q_0_tvalid <= 1'b0;
      vif.drv_cb.s_axis_sync_q_1_tvalid <= 1'b0;
      vif.drv_cb.s_axis_sync_q_2_tvalid <= 1'b0;
      vif.drv_cb.s_axis_sync_q_3_tvalid <= 1'b0;

      vif.drv_cb.s_axis_sync_q_0_tdata <= 'h0;
      vif.drv_cb.s_axis_sync_q_1_tdata <= 'h0;
      vif.drv_cb.s_axis_sync_q_2_tdata <= 'h0;
      vif.drv_cb.s_axis_sync_q_3_tdata <= 'h0;

      do begin
        uvm_config_db#(bit)::get(null, "*", "fetch_tvalid_seen", fetch_tvalid_seen);
        @(vif.drv_cb);
      end while (fetch_tvalid_seen == 0);
      uvm_config_db#(bit)::set(null, "*", "fetch_tvalid_seen", 0);
      @(vif.drv_cb);

      vif.drv_cb.s_axis_sync_q_0_tvalid <= current_bram.sync_valid_mask[0];
      vif.drv_cb.s_axis_sync_q_1_tvalid <= current_bram.sync_valid_mask[1];
      vif.drv_cb.s_axis_sync_q_2_tvalid <= current_bram.sync_valid_mask[2];
      vif.drv_cb.s_axis_sync_q_3_tvalid <= current_bram.sync_valid_mask[3];

      vif.drv_cb.s_axis_sync_q_0_tdata <= 32'h1;
      vif.drv_cb.s_axis_sync_q_1_tdata <= 32'h2;
      vif.drv_cb.s_axis_sync_q_2_tdata <= 32'h4;
      vif.drv_cb.s_axis_sync_q_3_tdata <= 32'h8;

      `uvm_info(get_type_name(), "BRAM_DRV: sync queues asserted, waiting for sync_queues handshake", UVM_LOW)

      wait(vif.drv_cb.s_axis_sync_q_0_tready || vif.drv_cb.s_axis_sync_q_1_tready || 
           vif.drv_cb.s_axis_sync_q_2_tready || vif.drv_cb.s_axis_sync_q_3_tready);

      // Give it one clock cycle for the data to be sampled by the DUT
      @(vif.drv_cb);
      vif.drv_cb.s_axis_sync_q_0_tvalid <= 0;
      vif.drv_cb.s_axis_sync_q_1_tvalid <= 0;
      vif.drv_cb.s_axis_sync_q_2_tvalid <= 0;
      vif.drv_cb.s_axis_sync_q_3_tvalid <= 0;

      `uvm_info(get_type_name(), "BRAM_DRV: Sync queues deasserted after sync_queues handshake", UVM_LOW);
    end
  endtask


  // ---------------------------------------------------------
  // Drive s2g Sync Queues 
  // ---------------------------------------------------------
  task drive_s2g_sync_queues();
    forever begin
      wait(current_bram != null); // Wait until an item is actually received
      @(vif.drv_cb);
      
      if (current_bram != null) begin
        // Apply s2g_sync_ready_mask to tready signals
        vif.drv_cb.s2g_sync_queue_0_tready <= current_bram.s2g_sync_ready_mask[0];
        vif.drv_cb.s2g_sync_queue_1_tready <= current_bram.s2g_sync_ready_mask[1];
        vif.drv_cb.s2g_sync_queue_2_tready <= current_bram.s2g_sync_ready_mask[2];
        vif.drv_cb.s2g_sync_queue_3_tready <= current_bram.s2g_sync_ready_mask[3];
        
      end else begin
        // Default: all ready
        vif.drv_cb.s2g_sync_queue_0_tready <= 1'b1;
        vif.drv_cb.s2g_sync_queue_1_tready <= 1'b1;
        vif.drv_cb.s2g_sync_queue_2_tready <= 1'b1;
        vif.drv_cb.s2g_sync_queue_3_tready <= 1'b1;
      end
    end
  endtask

  // ---------------------------------------------------------
  // Drive BRAM Reads
  // ---------------------------------------------------------
  task drive_bram_reads();
    int bram_addr;
    logic [(`AIACC_PE_DATA_WIDTH * `AIACC_SA_SIZE)-1:0] next_din;

    forever begin
      @(vif.drv_cb);

      if (vif.drv_cb.out_mem_en_a && !vif.drv_cb.out_mem_wen_a) begin
        bram_addr = vif.drv_cb.out_mem_addr_a;
        next_din = current_bram.bram[bram_addr];
        vif.drv_cb.out_mem_din_a <= next_din;
        @(vif.drv_cb);  // Wait for assignment to take effect

      `uvm_info(get_type_name(),
        $sformatf("BRAM_DRV: VALID READ:-> BRAM_ADDR = %0d, BRAM_DATA = %0h",
          bram_addr, next_din),
        UVM_LOW)
      end
      else begin
        // Ignore cycles where DUT is not driving valid read
      end
    end
  endtask
endclass