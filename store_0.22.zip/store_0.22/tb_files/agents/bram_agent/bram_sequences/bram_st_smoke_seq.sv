class bram_st_smoke_seq extends bram_st_base_seq;
  `uvm_object_utils(bram_st_smoke_seq)

  function new(string name = "bram_st_smoke_seq");
    super.new(name);
  endfunction

  virtual task body();
    bram_item b_item;

    repeat(1) begin
    b_item = bram_item::type_id::create("b_item");

    // ---- Selecting constraint mode ----
    b_item.constraint_mode(0);
    b_item.bram_pattern_c.constraint_mode(1);
    b_item.n_valid_c.constraint_mode(1);

    start_item(b_item);
    assert(b_item.randomize() with {
      sync_valid_mask == 4'b1111;
      s2g_sync_ready_mask == 4'b1111;
      }) 
      else 
        `uvm_error(get_type_name(), "BRAM randomization failed")
    `uvm_info(get_type_name(), "BRAM item randomized....................................", UVM_LOW)
    finish_item(b_item);
    end
  endtask
endclass
