class bram_st_partial_tready_seq extends bram_st_base_seq;
  `uvm_object_utils(bram_st_partial_tready_seq)

  function new(string name = "bram_st_partial_tready_seq");
    super.new(name);
  endfunction

  virtual task body();
    bram_item b_item;

    repeat(1) begin
    b_item = bram_item::type_id::create("b_item");

    // ---- Selecting constraint mode ----
    b_item.constraint_mode(0);
    b_item.bram_pattern_c.constraint_mode(1);
    b_item.n_valid_c.constraint_mode(1);

    start_item(b_item);
    assert(b_item.randomize() with {
        sync_valid_mask == 4'b1111;
        s2g_sync_ready_mask != 4'b0000;  // At least one ready
        s2g_sync_ready_mask inside {[4'b0001 : 4'b1111]};
        }) 
      else 
        `uvm_error(get_type_name(), "BRAM randomization failed")
    `uvm_info(get_type_name(), 
        $sformatf("BRAM item randomized: sync_valid=0x%0h, s2g_ready=0x%0h", 
                  b_item.sync_valid_mask, b_item.s2g_sync_ready_mask), 
        UVM_LOW)
    finish_item(b_item);
    end
  endtask
endclass
