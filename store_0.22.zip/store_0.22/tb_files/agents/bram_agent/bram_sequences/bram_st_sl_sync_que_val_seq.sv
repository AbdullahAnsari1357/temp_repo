class bram_st_sl_sync_que_val_seq extends bram_st_base_seq;
  `uvm_object_utils(bram_st_sl_sync_que_val_seq)
  // Class-level handle is REQUIRED for the Virtual Sequence to "see" it
  bram_item b_item;

  function new(string name = "bram_st_sl_sync_que_val_seq");
    super.new(name);
  endfunction

  virtual function bit do_randomize();
    return b_item.randomize() with {
      sync_valid_mask == 4'b1111;
      s2g_sync_ready_mask == 4'b1111;
    };
  endfunction

  virtual task body();
    repeat(1) begin
      b_item = bram_item::type_id::create("b_item");

      // ---- Selecting constraint mode ----
      b_item.constraint_mode(0);
      b_item.bram_pattern_c.constraint_mode(1);
      b_item.n_valid_c.constraint_mode(1);

      start_item(b_item);
        if (!do_randomize()) `uvm_error(get_type_name(), "Randomization failed")
      finish_item(b_item);
    end
  endtask
endclass

class bram_st_sl_sync_que_val_seq1 extends bram_st_sl_sync_que_val_seq;
  `uvm_object_utils(bram_st_sl_sync_que_val_seq1)

  function new(string name = "bram_st_sl_sync_que_val_seq1");
    super.new(name);
  endfunction

  // Override ONLY the randomization part
  virtual function bit do_randomize();
    return b_item.randomize() with {
      sync_valid_mask == 4'b0001;
      s2g_sync_ready_mask == 4'b1111;
    };
  endfunction
endclass

class bram_st_sl_sync_que_val_seq2 extends bram_st_sl_sync_que_val_seq;
  `uvm_object_utils(bram_st_sl_sync_que_val_seq2)

  function new(string name = "bram_st_sl_sync_que_val_seq2");
    super.new(name);
  endfunction

  // Override ONLY the randomization part
  virtual function bit do_randomize();
    return b_item.randomize() with {
      sync_valid_mask == 4'b0010;
      s2g_sync_ready_mask == 4'b1111;
    };
  endfunction
endclass

class bram_st_sl_sync_que_val_seq3 extends bram_st_sl_sync_que_val_seq;
  `uvm_object_utils(bram_st_sl_sync_que_val_seq3)

  function new(string name = "bram_st_sl_sync_que_val_seq3");
    super.new(name);
  endfunction

  // Override ONLY the randomization part
  virtual function bit do_randomize();
    return b_item.randomize() with {
      sync_valid_mask == 4'b0100;
      s2g_sync_ready_mask == 4'b1111;
    };
  endfunction
endclass

class bram_st_sl_sync_que_val_seq4 extends bram_st_sl_sync_que_val_seq;
  `uvm_object_utils(bram_st_sl_sync_que_val_seq4)

  function new(string name = "bram_st_sl_sync_que_val_seq4");
    super.new(name);
  endfunction

  // Override ONLY the randomization part
  virtual function bit do_randomize();
    return b_item.randomize() with {
      sync_valid_mask == 4'b1000;
      s2g_sync_ready_mask == 4'b1111;
    };
  endfunction
endclass
