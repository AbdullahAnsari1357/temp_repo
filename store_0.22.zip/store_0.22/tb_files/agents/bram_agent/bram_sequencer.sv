//============================================================
// Sequencer : bram_sequencer
//============================================================

class bram_sequencer extends uvm_sequencer #(bram_item);

  `uvm_component_utils(bram_sequencer)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

endclass