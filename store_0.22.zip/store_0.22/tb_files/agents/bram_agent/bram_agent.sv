//============================================================
// Agent : bram_agent
// Description : Reusable BRAM Agent
//============================================================

class bram_agent extends uvm_agent;

  `uvm_component_utils(bram_agent)

  bram_driver    driver;
  bram_monitor   monitor;
  bram_sequencer #(bram_item) sequencer;

  bram_agent_cfg cfg;
  bram_agent_cov cov;

  // ---------------------------------------------------------
  // Constructor
  // ---------------------------------------------------------
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction


  // ---------------------------------------------------------
  // Build Phase
  // ---------------------------------------------------------
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    if (!uvm_config_db#(bram_agent_cfg)::get(this, "", "cfg", cfg))
      `uvm_fatal("BRAM_AGENT", "Cannot get bram_agent_cfg")

    monitor = bram_monitor::type_id::create("monitor", this);
    cov = bram_agent_cov::type_id::create("cov", this);

    if (cfg.is_active == UVM_ACTIVE) begin
      driver    = bram_driver::type_id::create("driver", this);
      sequencer = bram_sequencer::type_id::create("sequencer", this);
    end
  endfunction


  // ---------------------------------------------------------
  // Connect Phase
  // ---------------------------------------------------------
  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);

    if (cfg.is_active == UVM_ACTIVE) begin
      driver.seq_item_port.connect(sequencer.seq_item_export);
    end
    monitor.cov_port.connect(cov.analysis_export); // Monitor -> Coverage Agent (Raw/Every-cycle Data)
  endfunction

endclass