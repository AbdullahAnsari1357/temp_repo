class st_missing_sync_valid_2_vseq extends st_base_vseq;
  `uvm_object_utils(st_missing_sync_valid_2_vseq)

  function new(string name = "st_missing_sync_valid_2_vseq");
    super.new(name);
  endfunction

  virtual clk_rst_if clk_rst_vif;
  event all_done_evt;

  //---------------------------------------------------------
  // Set Scoreboard Checker Enabler Before Sending Traffic
  //---------------------------------------------------------
  task pre_body();
    uvm_config_db#(store_chk_pkg::store_chk_mode_e)::set(null,"uvm_test_top.env.scb", "chk_mode", store_chk_pkg::st_missing_sync_valid_2_ch);
  endtask

  task body();

    if (starting_phase != null) starting_phase.raise_objection(this);
    `uvm_info("VSEQ", "Running Store Test Virtual Sequence", UVM_LOW)

    //-------------------------------------------
    // Sanity checks
    //-------------------------------------------
    if (p_sequencer == null) begin
      `uvm_fatal(get_type_name(), "p_sequencer is NULL!")
    end

    if (p_sequencer.fetch_seqr == null) begin
      `uvm_fatal(get_type_name(),
        "Fetch sequencer handle is null! Check virtual sequencer connections.")
    end

    if (p_sequencer.bram_seqr == null) begin
      `uvm_fatal(get_type_name(),
        "BRAM sequencer handle is null! Check virtual sequencer connections.")
    end

    
    //-------------------------------------------
      $display("[%0t] >>> Inside st_missing_sync_valid_2_vseq::body()", $time);
    //-------------------------------------------

    fork
      begin : FETCH_BRAM_THREAD
        fetch_st_missing_sync_valid_2_seq f_seq;
        bram_st_missing_sync_valid_2_seq b_seq;

        repeat (10) begin
            f_seq = fetch_st_missing_sync_valid_2_seq::type_id::create("f_seq");
            b_seq = bram_st_missing_sync_valid_2_seq::type_id::create("b_seq");
            fork
                begin
                    fork
                        f_seq.start(p_sequencer.fetch_seqr);
                        b_seq.start(p_sequencer.bram_seqr);
                    join
                end
                begin
                    #6000ns;
                    `uvm_warning("TIMEOUT", "Design stalled for > 6us! Triggering Reset.")
                    apply_rst(4);
                end
            join_any // Terminate the fork as soon as ONE branch completes
            disable fork; // Kill the remaining thread (stops the timer if sequences finish early)
        end
        -> all_done_evt;
      end

      // begin : RESET_THREAD
      //      #450ns;
      //      apply_rst(4);
      // end

    join_none

    @all_done_evt;
    if (starting_phase != null) starting_phase.drop_objection(this);
    `uvm_info(get_type_name(),
              "Store test sequence completed successfully",
              UVM_LOW)
    disable fork;
    
  endtask : body

  //----------------------------------------
  // Get reset interface once
  //----------------------------------------
  task get_clk_rst_vif();
    if (clk_rst_vif == null) begin
      if (!uvm_config_db#(virtual clk_rst_if)::get(null, "uvm_test_top.env", "clk_rst_vif", clk_rst_vif)) begin
        `uvm_fatal(get_type_name(), "clk_rst_vif not found in config DB")
      end
    end
  endtask

  //----------------------------------------
  // Reset task (call anywhere)
  //----------------------------------------
  task apply_rst(int unsigned reset_width_clks = 2);
    get_clk_rst_vif();

    `uvm_info(get_type_name(),
      $sformatf("Applying reset from vseq for %0d cycles............", reset_width_clks),
      UVM_LOW)

    clk_rst_vif.apply_reset(.reset_width_clks(reset_width_clks));
  endtask
endclass : st_missing_sync_valid_2_vseq
