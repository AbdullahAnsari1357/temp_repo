class st_base_vseq extends uvm_sequence;

  `uvm_object_utils(st_base_vseq)
  `uvm_declare_p_sequencer(virtual_sequencer)

  function new(string name="st_base_vseq");
    super.new(name);
  endfunction

  // Optional: common utility tasks can go here later

endclass
