class st_stride_vseq extends st_base_vseq;
  `uvm_object_utils(st_stride_vseq)

  function new(string name = "st_stride_vseq");
    super.new(name);
  endfunction

  virtual clk_rst_if clk_rst_vif;
  event all_done_evt;

  //---------------------------------------------------------
  // Set Scoreboard Checker Enabler Before Sending Traffic
  //---------------------------------------------------------
  task pre_body();
     uvm_config_db#(store_chk_pkg::store_chk_mode_e)::set(null,"uvm_test_top.env.scb", "chk_mode", store_chk_pkg::st_stride_ch);
  endtask

  task body();

    if (starting_phase != null) starting_phase.raise_objection(this);
    `uvm_info("VSEQ", "Running Store Test Virtual Sequence", UVM_LOW)

    //-------------------------------------------
    // Sanity checks
    //-------------------------------------------
    if (p_sequencer == null) begin
      `uvm_fatal(get_type_name(), "p_sequencer is NULL!")
    end

    if (p_sequencer.fetch_seqr == null) begin
      `uvm_fatal(get_type_name(),
        "Fetch sequencer handle is null! Check virtual sequencer connections.")
    end

    if (p_sequencer.bram_seqr == null) begin
      `uvm_fatal(get_type_name(),
        "BRAM sequencer handle is null! Check virtual sequencer connections.")
    end

    
    //-------------------------------------------
      $display("[%0t] >>> Inside st_stride_vseq::body()", $time);
    //-------------------------------------------

    fork
      begin : FETCH_BRAM_THREAD
        fetch_st_stride_seq f_seq;
        fetch_st_stride_seq1 f_seq1;
        fetch_st_stride_seq2 f_seq2;
        fetch_st_stride_seq3 f_seq3;
        fetch_st_stride_seq4 f_seq4;
        bram_st_stride_seq b_seq;
        begin
          f_seq1 = fetch_st_stride_seq1::type_id::create("f_seq1");
          b_seq = bram_st_stride_seq::type_id::create("b_seq");

          fork
           f_seq1.start(p_sequencer.fetch_seqr);
           b_seq.start(p_sequencer.bram_seqr);
          join
          #60ns;//optional delay between two instructions
        //  apply_rst(4);//applying reset deliberately to terminate the DUT stall(In case of invalid opcodes etc)
        end
        begin
          f_seq2 = fetch_st_stride_seq2::type_id::create("f_seq2");

          f_seq2.start(p_sequencer.fetch_seqr);
          #60ns;//optional delay between two instructions
        //  apply_rst(4);//applying reset deliberately to terminate the DUT stall(In case of invalid opcodes etc)
        end
        begin
          f_seq3 = fetch_st_stride_seq3::type_id::create("f_seq3");

          f_seq3.start(p_sequencer.fetch_seqr);
          #60ns;//optional delay between two instructions
        //  apply_rst(4);//applying reset deliberately to terminate the DUT stall(In case of invalid opcodes etc)
        end
        begin
          f_seq4 = fetch_st_stride_seq4::type_id::create("f_seq4");

          f_seq4.start(p_sequencer.fetch_seqr);
          #60ns;//optional delay between two instructions
        //  apply_rst(4);//applying reset deliberately to terminate the DUT stall(In case of invalid opcodes etc)
        end
        begin
          f_seq = fetch_st_stride_seq::type_id::create("f_seq");

          f_seq.start(p_sequencer.fetch_seqr);
          #60ns;//optional delay between two instructions
        //  apply_rst(4);//applying reset deliberately to terminate the DUT stall(In case of invalid opcodes etc)
        end
        begin
          f_seq4 = fetch_st_stride_seq4::type_id::create("f_seq4");

          f_seq4.start(p_sequencer.fetch_seqr);
          #60ns;//optional delay between two instructions
        //  apply_rst(4);//applying reset deliberately to terminate the DUT stall(In case of invalid opcodes etc)
        end
        -> all_done_evt;
      end

      // begin : RESET_THREAD
      //      #450ns;
      //      apply_rst(4);
      // end

    join_none

    @all_done_evt;
    if (starting_phase != null) starting_phase.drop_objection(this);
    `uvm_info(get_type_name(), "Store test sequence completed successfully", UVM_LOW)
    disable fork;
    
  endtask : body

  //----------------------------------------
  // Get reset interface once
  //----------------------------------------
  task get_clk_rst_vif();
    if (clk_rst_vif == null) begin
      if (!uvm_config_db#(virtual clk_rst_if)::get(null, "uvm_test_top.env", "clk_rst_vif", clk_rst_vif)) begin
        `uvm_fatal(get_type_name(), "clk_rst_vif not found in config DB")
      end
    end
  endtask

  //----------------------------------------
  // Reset task (call anywhere)
  //----------------------------------------
  task apply_rst(int unsigned reset_width_clks = 2);
    get_clk_rst_vif();

    `uvm_info(get_type_name(),
      $sformatf("Applying reset from vseq for %0d cycles............", reset_width_clks),
      UVM_LOW)

    clk_rst_vif.apply_reset(.reset_width_clks(reset_width_clks));
  endtask
endclass : st_stride_vseq
