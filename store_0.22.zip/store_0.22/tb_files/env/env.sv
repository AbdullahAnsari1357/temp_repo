//============================================================
// Environment : env
// Description : Top-level environment
//============================================================

class env extends uvm_env;

  `uvm_component_utils(env)

  // Agents
  fetch_agent fetch_ag;
  bram_agent  bram_ag;
  hbm_agent   hbm_ag;

  // Scoreboard
  scoreboard scb;

  // Virtual Sequencer
  virtual_sequencer vseqr;

  // Config
  env_cfg cfg;

  //---------------------------------------------------------
  // Constructor
  //---------------------------------------------------------
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction


  //---------------------------------------------------------
  // Build Phase
  //---------------------------------------------------------
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    // ------------------------------------------------------
    // Get ENV Config
    // ------------------------------------------------------
    if (!uvm_config_db#(env_cfg)::get(this, "", "cfg", cfg))
      `uvm_fatal("ENV", "Cannot get env_cfg")

    // ------------------------------------------------------
    // Pass Agents' Config
    // ------------------------------------------------------
    uvm_config_db#(fetch_agent_cfg)::set(this, "fetch_ag*", "cfg", cfg.fetch_cfg);
    uvm_config_db#(bram_agent_cfg)::set(this, "bram_ag*",  "cfg", cfg.bram_cfg);
    uvm_config_db#(hbm_agent_cfg)::set(this, "hbm_ag*",   "cfg", cfg.hbm_cfg);

    // ------------------------------------------------------
    // Create Agents
    // ------------------------------------------------------
    fetch_ag = fetch_agent::type_id::create("fetch_ag", this);
    bram_ag  = bram_agent::type_id::create("bram_ag", this);
    hbm_ag   = hbm_agent::type_id::create("hbm_ag", this);

    // ------------------------------------------------------
    // Create Scoreboard
    // ------------------------------------------------------
    scb = scoreboard::type_id::create("scb", this);

    // ------------------------------------------------------
    // Create Vitual Sequencer
    // ------------------------------------------------------
    vseqr = virtual_sequencer::type_id::create("vseqr", this);
  endfunction


  //---------------------------------------------------------
  // Connect Phase
  //---------------------------------------------------------
  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    // Connect monitors -> TLM FIFOs inside scoreboard

    fetch_ag.monitor.analysis_port.connect(scb.fetch_fifo.analysis_export);
    bram_ag.monitor.data_port.connect(scb.bram_fifo.analysis_export); // Connection A: Monitor -> Scoreboard (Filtered/Selective-cycle Data)
    hbm_ag.monitor.analysis_port.connect(scb.hbm_fifo.analysis_export);

    if (cfg.fetch_cfg.is_active == UVM_ACTIVE)
        vseqr.fetch_seqr = fetch_ag.sequencer;

    if (cfg.bram_cfg.is_active == UVM_ACTIVE)
        vseqr.bram_seqr = bram_ag.sequencer;

    if (cfg.hbm_cfg.is_active == UVM_ACTIVE)
        vseqr.hbm_seqr = hbm_ag.sequencer;
  endfunction

endclass