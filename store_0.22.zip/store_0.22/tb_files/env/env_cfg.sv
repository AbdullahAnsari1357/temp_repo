//============================================================
// Config : env_cfg
// Description : Environment configuration
//============================================================

class env_cfg extends uvm_object;

  `uvm_object_utils(env_cfg)

  // Agent configs
  fetch_agent_cfg fetch_cfg;
  bram_agent_cfg  bram_cfg;
  hbm_agent_cfg   hbm_cfg;

  function new(string name = "tb_env_cfg");
    super.new(name);

    fetch_cfg = fetch_agent_cfg::type_id::create("fetch_cfg");
    bram_cfg  = bram_agent_cfg::type_id::create("bram_cfg");
    hbm_cfg   = hbm_agent_cfg::type_id::create("hbm_cfg");
  endfunction

endclass