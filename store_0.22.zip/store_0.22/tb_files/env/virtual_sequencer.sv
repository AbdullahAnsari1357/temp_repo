//============================================================
// Virtual Sequencer : virtual_sequencer
//============================================================

class virtual_sequencer extends uvm_sequencer;

  `uvm_component_utils(virtual_sequencer)

  // Handles to real sequencers
  fetch_sequencer fetch_seqr;
  bram_sequencer  bram_seqr;
  hbm_sequencer   hbm_seqr;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

endclass