//============================================================
// Scoreboard : scoreboard
//============================================================

class scoreboard extends uvm_component;

  `uvm_component_utils(scoreboard)

  // ----------------------------
  // BYTE-addressed memory models
  // ----------------------------
  longint unsigned current_dram_base;
  logic [6:0] last_opcode;
  bit bram_collect_en;
  byte unsigned exp_byte_q[$];

  // ----------------------------
  // Checker enablers
  // ----------------------------
  store_chk_pkg::store_chk_mode_e chk_mode;

  // ----------------------------
  // AW tracking
  // ----------------------------
  typedef struct {
    longint unsigned base_addr;
    int bytes_per_beat;
    int beats_expected;
    bit [1:0] burst;
    int beat_idx;
  } aw_state_t;

  aw_state_t aw_q[$];

  // ---------------------------------------------
  // TLM FIFOs
  // ---------------------------------------------
  uvm_tlm_analysis_fifo #(fetch_item) fetch_fifo;
  uvm_tlm_analysis_fifo #(bram_item)  bram_fifo;
  uvm_tlm_analysis_fifo #(hbm_item)   hbm_fifo;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  //---------------------------------------------------------
  // Build Phase
  //---------------------------------------------------------
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    fetch_fifo = new("fetch_fifo", this);
    bram_fifo  = new("bram_fifo", this);
    hbm_fifo   = new("hbm_fifo", this);
    current_dram_base = '0;
  endfunction

  //---------------------------------------------------------
  // Connect Phase
  //---------------------------------------------------------
  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
  endfunction

  //---------------------------------------------------------
  // Run Phase
  //---------------------------------------------------------  
  task run_phase(uvm_phase phase);
    `uvm_info("SCB_WAIT", "Scoreboard stalled. Waiting for vseq to set chk_mode...", UVM_LOW)
    uvm_config_db#(store_chk_pkg::store_chk_mode_e)::wait_modified(this, "", "chk_mode");
    fork
      process_fetch_fifo();
      process_bram_fifo();
      process_hbm_fifo();
    join

  endtask

  //=========================================================
  // Fetch Processing
  //=========================================================
  task process_fetch_fifo();
     fetch_item f;
     forever begin
       fetch_fifo.get(f);
       current_dram_base = f.insn.dram_base_addr;
       last_opcode       = f.insn.opcode;
       `uvm_info("SCB_FETCH",
      $sformatf("Fetched opcode = 0x%0h", last_opcode),
      UVM_LOW)
     end
   endtask

  //=========================================================
  // BRAM Processing
  //=========================================================
  task process_bram_fifo();
    bram_item b;
    bit [31:0] w;
    store_chk_pkg::store_chk_mode_e mode;

    forever begin
      //-------------- Get Checker Enablers Before Processing -----------------
      // get from test / vseq
      if (!uvm_config_db#(store_chk_mode_e)::get(this, "", "chk_mode", chk_mode)) begin
        chk_mode = st_none_ch;
      end
      `uvm_info("CHK_MODE",
        $sformatf("Scoreboard checker mode = %s",
                  chk_mode_to_string(chk_mode)),
        UVM_LOW)

      mode = chk_mode;

      bram_fifo.get(b);

        // -------------------------------------------------
      // 1) ALWAYS compute expected bytes
      // ------------------------------------------------- 
      begin
        w = b.out_mem_rdata;

        exp_byte_q.push_back(w[7:0]);
        exp_byte_q.push_back(w[15:8]);
        exp_byte_q.push_back(w[23:16]);
        exp_byte_q.push_back(w[31:24]);

        `uvm_info("SCB_BRAM",
            $sformatf("BRAM addr=%0d data=0x%08h q_size=%0d",
                      b.out_mem_addr, w, exp_byte_q.size()),
            UVM_LOW);
      end

      // -------------------------------------------------
      // 2) CONDITIONAL checking 
      // -------------------------------------------------
      case (mode)
        st_reset_ch: begin
          if (!b.rst_n && b.out_mem_en)
            `uvm_info("RST_CHK",
              "BRAM activity during reset", UVM_LOW);
        end

        st_data_integrity_check_ch: begin
          if(b.read_valid)begin
            bit [31:0] exp_w;
            bit [31:0] act_w;

            // -------------------------------
            // Address-based predictor
            // -------------------------------
            exp_w = 32'hCAFE_0000 | b.out_mem_addr;

            // Actual read data from DUT
            act_w = b.out_mem_rdata;//b.bram is the bram data recieved from monitor, receiving from DUT

            // -------------------------------
            // Compare
            // -------------------------------
            if (act_w !== exp_w) begin
              `uvm_error("BRAM_DATA_MISMATCH",
                $sformatf(
                  "BRAM read mismatch: addr=%0d (0x%0h) EXP=0x%08h ACT=0x%08h",
                  b.out_mem_addr, b.out_mem_addr,
                  exp_w, act_w
                ))
            end
            else begin
              `uvm_info("BRAM_DATA_OK",
                $sformatf(
                  "BRAM read OK: addr=%0d read_data=0x%08h",
                  b.out_mem_addr, act_w
                ),
                UVM_LOW)
            end
          end
        end

        st_invalid_insn_ch,
        st_rand_insn_stream_ch: begin
          // -------------------------------------------------
          // INVALID OPCODE CHECK (BRAM SIDE)
          // -------------------------------------------------
          if (last_opcode != 7'h1) begin
            if (b.out_mem_en) begin
              `uvm_error("INV_OPCODE_BRAM",
                $sformatf(
                  "BRAM activity seen for INVALID opcode 0x%0h (addr=%0d data=0x%08h)",
                  last_opcode, b.out_mem_addr, b.out_mem_rdata
                ))
            end
          end
        end


        default: begin
          // no checker enabled
        end

      endcase
    end
  endtask

  //=========================================================
  // HBM Processing (Map bytes using AW + WSTRB)
  //=========================================================
  task process_hbm_fifo();
    hbm_item h;
    aw_state_t aw;
    store_chk_pkg::store_chk_mode_e mode;

    longint unsigned beat_addr;
    longint unsigned byte_addr;
    byte unsigned exp_b;
    byte unsigned act_b;
    bit exp_last_beat;

    forever begin
      if (!uvm_config_db#(store_chk_mode_e)::get(this, "", "chk_mode", chk_mode)) begin
        chk_mode = st_none_ch;
      end
      mode = chk_mode;
      
      hbm_fifo.get(h);

    // ---------------------------------
    // RESET handling (ALWAYS)
    // ---------------------------------
      if (!h.rst_n) begin
        aw_q.delete();
        exp_byte_q.delete();

        case (mode)
          st_reset_ch: begin
            if (h.aw_valid || h.wvalid)
              `uvm_info("RST_CHK",
                "AXI write activity seen during reset", UVM_LOW);
          end

          default: begin
          // no checker enabled
          end
        endcase

        continue;
      end

    // ---------------------------------
    // AW processing (ALWAYS)
    // ---------------------------------
      if (h.aw_valid) begin
        aw.base_addr      = h.aw_addr;
        aw.bytes_per_beat = 1 << h.aw_size;
        aw.beats_expected = int'(h.aw_len) + 1;
        aw.burst          = h.aw_burst;
        aw.beat_idx       = 0;

        aw_q.push_back(aw);

        `uvm_info("SCB_AW",
          $sformatf("AW base=0x%0h beats=%0d bytes/beat=%0d",
                    aw.base_addr, aw.beats_expected, aw.bytes_per_beat),
          UVM_LOW)
        continue;
      end

      if (aw_q.size() == 0)
        continue;

      aw = aw_q[0];

      beat_addr = compute_burst_addr(
                    aw.base_addr,
                    aw.beat_idx,
                    aw.bytes_per_beat,
                    aw.burst,
                    aw.beats_expected);

      `uvm_info("SCB_W",
        $sformatf("Beat %0d addr=0x%0h WDATA=0x%08h WSTRB=0x%0h",
                  aw.beat_idx, beat_addr, h.wdata[31:0], h.wstrb),
        UVM_LOW)

    // ---------------------------------
    // BYTE-wise processing (ALWAYS)
    // ---------------------------------
      for (int lane = 0; lane < 4; lane++) begin
        if (h.wstrb[lane]) begin
          if (exp_byte_q.size() == 0) begin
            `uvm_warning("SCB_UNDERFLOW",
              $sformatf("Expected from empty byte_queue at HBM addr 0x%0h", beat_addr))
            continue;
          end
          exp_b     = exp_byte_q.pop_front();
          act_b     = h.wdata[lane*8 +: 8];
          byte_addr = beat_addr + lane;

          `uvm_info("SCB_BYTES",
            $sformatf("ADDR 0x%0h EXP=0x%02h ACT=0x%02h",
                      byte_addr, exp_b, act_b),
            UVM_LOW)

          // ---------------------------------
          // Per-BYTE CONDITIONAL CHECKING
          // ---------------------------------
          case (mode)
            st_sl_data_store_ch,
            st_single_block_store_ch,
            st_multi_block_store_ch,
            st_stride_ch,
            st_mul_sync_ques_active_ch,
            st_cont_read_ch,
            st_partial_tready_ch: begin
              if (exp_b == act_b) begin
                `uvm_info("Checker:BYTE_PASSED", $sformatf("ADDR 0x%0h EXP=0x%02h ACT=0x%02h", byte_addr, exp_b, act_b), UVM_LOW)
              end
              else begin
                `uvm_error("SCB_MISMATCH", $sformatf("ADDR 0x%0h EXP=0x%02h ACT=0x%02h", byte_addr, exp_b, act_b))
              end
            end

            st_invalid_insn_ch,
            st_rand_insn_stream_ch: begin
              // -------------------------------------------------
              // INVALID OPCODE CHECK (HBM SIDE)
              // -------------------------------------------------
              if (last_opcode != 7'h1) begin
                if (h.aw_valid || h.wvalid) begin
                  `uvm_error("INV_OPCODE_HBM",
                    $sformatf(
                      "HBM write seen for INVALID opcode 0x%0h (AW=%0b W=%0b)",
                      last_opcode, h.aw_valid, h.wvalid
                    ))
                end
              end
            end

            // add more checkers here later
            // st_seq_rd_pattern_ch:
            // st_mem_out_ch:
            // ...

            default: begin
              // no checker enabled
            end
          endcase
        end
      end

    // -------------------------------------------
    // Per-BEAT WLAST checking (protocol checker)
    // -------------------------------------------
      case (mode)
        st_single_block_store_ch, 
        st_multi_block_store_ch,
        st_stride_ch,
        st_mul_sync_ques_active_ch,
        st_cont_read_ch,
        st_partial_tready_ch: begin
          exp_last_beat = (aw.beat_idx == aw.beats_expected - 1);

          if (h.wlast && !exp_last_beat)
            `uvm_error("WLAST_CHK", "WLAST asserted early");

          if (!h.wlast && exp_last_beat)
            `uvm_error("WLAST_CHK", "WLAST missing on last beat");
        end

      // if (aw_q.size() == 0)
      //    `uvm_fatal("SCB", "W received without AW");

        default: begin
          // no checker enabled
        end
      endcase

    // ---------------------------------
    // Advance AW state (ALWAYS)
    // ---------------------------------
      aw.beat_idx++;
      aw_q[0] = aw;

      if (h.wlast || aw.beat_idx == aw.beats_expected) begin
        aw_q.pop_front();
        `uvm_info("SCB_AW", "AXI transaction complete", UVM_LOW)
      end
    end
  endtask

  function longint unsigned compute_burst_addr(
    longint unsigned base_addr,
    int beat_idx,
    int bytes_per_beat,
    bit [1:0] burst,
    int beats_expected
    );
    longint unsigned wrap_size;
    longint unsigned wrap_base;
    longint unsigned offset;

    case (burst)
      2'b00: begin
        // FIXED
        return base_addr;
      end

      2'b01: begin
        // INCR
        return base_addr + beat_idx * bytes_per_beat;
      end

      2'b10: begin
        // WRAP
        wrap_size = beats_expected * bytes_per_beat;
        wrap_base = (base_addr / wrap_size) * wrap_size;
        offset    = (base_addr - wrap_base +
                    beat_idx * bytes_per_beat) % wrap_size;
        return wrap_base + offset;
      end

      default: begin
        return base_addr + beat_idx * bytes_per_beat;
      end
    endcase
  endfunction

endclass