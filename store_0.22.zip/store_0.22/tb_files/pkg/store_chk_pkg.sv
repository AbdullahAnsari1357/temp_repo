package store_chk_pkg;
  typedef enum {
    st_none_ch,
    st_smoke_ch,
    st_sl_data_store_ch,
    st_reset_ch,
    st_mem_out_ch,
    st_inst0_ch,
    st_inst1_ch,
    st_inst2_ch,
    st_inst3_ch,
    st_inst_all_ch,
    st_single_block_store_ch,
    st_multi_block_store_ch,
    st_invalid_insn_ch,
    st_nil_offset_ch,
    st_offset_enable_ch,
    st_seq_rd_pattern_ch,
    st_data_integrity_check_ch,
    st_rand_insn_stream_ch,
    st_bram_ooa_ch,
    st_cont_read_ch,
    st_mix_data_compute_ch,
    st_rand_sync_queue_ch,
    st_missing_sync_valid_0_ch,
    st_missing_sync_valid_1_ch,
    st_missing_sync_valid_2_ch,
    st_missing_sync_valid_3_ch,
    st_sl_sync_que_val_ch,
    st_stride_ch,
    st_mul_sync_ques_active_ch,
    st_rand_insn_stream2_ch,
    st_partial_tready_ch,
    st_full_mat_ch
    // add more later
  } store_chk_mode_e;

  // ----------------------------------------
  // Enum → string conversion (SINGLE SOURCE)
  // ----------------------------------------
  function string chk_mode_to_string(store_chk_mode_e mode);
    case (mode)
      st_none_ch:                           return "st_none_ch";
      st_smoke_ch:                          return "st_smoke_ch";
      st_sl_data_store_ch:                  return "st_sl_data_store_ch";
      st_reset_ch:                          return "st_reset_ch";
      st_mem_out_ch:                        return "st_mem_out_ch";
      st_inst0_ch:                          return "st_inst0_ch";
      st_inst1_ch:                          return "st_inst1_ch";
      st_inst2_ch:                          return "st_inst2_ch";
      st_inst3_ch:                          return "st_inst3_ch";
      st_single_block_store_ch:             return "st_single_block_store_ch";
      st_multi_block_store_ch:              return "st_multi_block_store_ch";
      st_invalid_insn_ch:                   return "st_invalid_insn_ch";
      st_nil_offset_ch:                     return "st_nil_offset_ch";
      st_offset_enable_ch:                  return "st_offset_enable_ch";
      st_seq_rd_pattern_ch:                 return "st_seq_rd_pattern_ch";
      st_data_integrity_check_ch:           return "st_data_integrity_check_ch";
      st_rand_insn_stream_ch:               return "st_rand_insn_stream_ch";
      st_bram_ooa_ch:                       return "st_bram_ooa_ch";
      st_cont_read_ch:                      return "st_cont_read_ch";
      st_mix_data_compute_ch:               return "st_mix_data_compute_ch";
      st_rand_sync_queue_ch:                return "st_rand_sync_queue_ch";
      st_missing_sync_valid_0_ch:           return "st_missing_sync_valid_0_ch";
      st_missing_sync_valid_1_ch:           return "st_missing_sync_valid_1_ch";
      st_missing_sync_valid_2_ch:           return "st_missing_sync_valid_2_ch";
      st_missing_sync_valid_3_ch:           return "st_missing_sync_valid_3_ch";
      st_sl_sync_que_val_ch:                return "st_sl_sync_que_val_ch";
      st_stride_ch:                         return "st_stride_ch";
      st_mul_sync_ques_active_ch:           return "st_mul_sync_ques_active_ch";
      st_rand_insn_stream2_ch:              return "st_rand_insn_stream2_ch";
      st_partial_tready_ch:                 return "st_partial_tready_ch";
      st_full_mat_ch:                       return "st_full_mat_ch";
      default:                              return "UNKNOWN_CHK_MODE";
    endcase
  endfunction

endpackage
