class c_3_1;
    rand bit[127:0] insn; // rand_mode = ON 

    constraint fetch_c1_this    // (constraint_mode = ON) (../tb_files/agents/fetch_agent/fetch_item.sv:28)
    {
       ((insn[92:77]) == 16'h4);
    }
    constraint fetch_c2_this    // (constraint_mode = ON) (../tb_files/agents/fetch_agent/fetch_item.sv:42)
    {
       ((insn[92:77]) == (4 * 4));
    }
endclass

program p_3_1;
    c_3_1 obj;
    string randState;

    initial
        begin
            obj = new;
            randState = "xzx01zz001x0x01z1x1011z1xx010zz0xxzxxxzxxzzzzzzzxzxxzxxxxzzzzzxz";
            obj.set_randstate(randState);
            obj.randomize();
        end
endprogram
