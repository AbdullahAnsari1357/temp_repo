class c_5_1;
    rand bit[127:0] insn; // rand_mode = ON 

    constraint fetch_c1_this    // (constraint_mode = ON) (../tb_files/agents/fetch_agent/fetch_item.sv:28)
    {
       ((insn[92:77]) == 16'h4);
    }
    constraint fetch_c2_this    // (constraint_mode = ON) (../tb_files/agents/fetch_agent/fetch_item.sv:42)
    {
       ((insn[92:77]) == (4 * 4));
    }
endclass

program p_5_1;
    c_5_1 obj;
    string randState;

    initial
        begin
            obj = new;
            randState = "zzx110x0x1x01x1zxzxx0z1z0x011zz0xzzxzxxxzxzzxxxzzzxzxxxzxxzxzxzz";
            obj.set_randstate(randState);
            obj.randomize();
        end
endprogram
