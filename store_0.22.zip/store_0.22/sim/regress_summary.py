import os
import re

log_dir = "logs"
results = []

print("\n" + "="*80)
print(f"{'VSEQ NAME':<40} | {'SEED':<12} | {'STATUS':<10}")
print("="*80)

if not os.path.exists(log_dir):
    print("No logs found.")
    exit()

for log_file in os.listdir(log_dir):
    if log_file.endswith(".log"):
        path = os.path.join(log_dir, log_file)
        status = "RUNNING"
        seed = "N/A"
        
        # Extract seed from filename (vseq_seed1234.log)
        seed_match = re.search(r'seed(\d+)', log_file)
        if seed_match: seed = seed_match.group(1)
        
        with open(path, 'r') as f:
            content = f.read()
            if "UVM_ERROR :    0" in content and "UVM_FATAL :    0" in content:
                status = "\033[92mPASS\033[0m" # Green
            elif "UVM_ERROR" in content or "UVM_FATAL" in content:
                status = "\033[91mFAIL\033[0m" # Red
            else:
                status = "\033[93mINCOMPLETE\033[0m" # Yellow

        vseq_name = log_file.split('_seed')[0]
        print(f"{vseq_name:<40} | {seed:<12} | {status:<10}")

print("="*80 + "\n")
