//============================================================
// Interface : fetch_if
// Description : Interface between FETCH driver and DUT
//============================================================

interface fetch_if (input logic clk, input logic rst_n);

  // ---------------------------------------------------------
  // Stream Signals
  // ---------------------------------------------------------
  logic         store_queue_tvalid;
  logic         store_queue_tready;
  logic [127:0] store_queue_tdata;
  logic         ready_for_next_insn;

  // ---------------------------------------------------------
  // Driver Clocking Block
  // ---------------------------------------------------------
  clocking drv_cb @(posedge clk);
    output store_queue_tvalid;
    output store_queue_tdata;
    input  store_queue_tready;
    input  ready_for_next_insn;
  endclocking

  // ---------------------------------------------------------
  // Monitor Clocking Block
  // ---------------------------------------------------------
  clocking mon_cb @(posedge clk);
    input store_queue_tvalid;
    input store_queue_tdata;
    input store_queue_tready;
  endclocking

  // ---------------------------------------------------------
  // Modports
  // ---------------------------------------------------------
  modport DRV_MP (clocking drv_cb, input rst_n);
  modport MON_MP (clocking mon_cb, input rst_n);

endinterface