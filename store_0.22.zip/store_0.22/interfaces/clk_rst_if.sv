interface clk_rst_if ();

  //----------------------------------------
  // Signals
  //----------------------------------------
  logic clk;
  logic rst_n;

  //----------------------------------------
  // Clock Generation
  //----------------------------------------
  parameter CLK_PERIOD = 10ns;

  initial begin
    clk = 0;
    forever #(CLK_PERIOD/2) clk = ~clk;
  end

  initial begin
    rst_n = 0;
    repeat (5) @(posedge clk);
    rst_n = 1;
  end

  //----------------------------------------
  // Reset Task
  //----------------------------------------
  task apply_reset(
    int unsigned reset_width_clks = 2);

    rst_n = 0;
    repeat (reset_width_clks) @(posedge clk);
    rst_n = 1;
  endtask

endinterface