//============================================================
// Interface : bram_if
// Description : BRAM + Sync Queue Interface
//============================================================

interface bram_if(input logic clk, input logic rst_n);

  // ---------------------------------------------------------
  // Incoming Sync Queues
  // ---------------------------------------------------------
  logic [`AIACC_SYNC_QUEUE_DATA_WIDTH-1:0] s_axis_sync_q_0_tdata;
  logic                                    s_axis_sync_q_0_tvalid;
  logic                                    s_axis_sync_q_0_tready;

  logic [`AIACC_SYNC_QUEUE_DATA_WIDTH-1:0] s_axis_sync_q_1_tdata;
  logic                                    s_axis_sync_q_1_tvalid;
  logic                                    s_axis_sync_q_1_tready;

  logic [`AIACC_SYNC_QUEUE_DATA_WIDTH-1:0] s_axis_sync_q_2_tdata;
  logic                                    s_axis_sync_q_2_tvalid;
  logic                                    s_axis_sync_q_2_tready;

  logic [`AIACC_SYNC_QUEUE_DATA_WIDTH-1:0] s_axis_sync_q_3_tdata;
  logic                                    s_axis_sync_q_3_tvalid;
  logic                                    s_axis_sync_q_3_tready;

  logic                                    axi_str_handshake;


  //--------------------------------------------------------------------------
  // Reverse sync queues (from store to global)
  //--------------------------------------------------------------------------

  logic [`AIACC_SYNC_QUEUE_DATA_WIDTH-1:0] s2g_sync_queue_0_tdata;
  logic                                    s2g_sync_queue_0_tvalid;
  logic                                    s2g_sync_queue_0_tready;

  logic [`AIACC_SYNC_QUEUE_DATA_WIDTH-1:0] s2g_sync_queue_1_tdata;
  logic                                    s2g_sync_queue_1_tvalid;
  logic                                    s2g_sync_queue_1_tready;

  logic [`AIACC_SYNC_QUEUE_DATA_WIDTH-1:0] s2g_sync_queue_2_tdata;
  logic                                    s2g_sync_queue_2_tvalid;
  logic                                    s2g_sync_queue_2_tready;

  logic [`AIACC_SYNC_QUEUE_DATA_WIDTH-1:0] s2g_sync_queue_3_tdata;
  logic                                    s2g_sync_queue_3_tvalid;
  logic                                    s2g_sync_queue_3_tready;


  //--------------------------------------------------------------------------
  // Status / Error signals
  //--------------------------------------------------------------------------

  logic barrier_response_store;
  logic error_store;
  logic store_valid;

  // -------------------------------------------------------------------------
  // BRAM Read Interface
  // -------------------------------------------------------------------------
  logic [`AIACC_INP_BRAM_ADDR_WIDTH-1:0]                out_mem_addr_a;
  logic                                                 out_mem_en_a;
  logic [(`AIACC_PE_DATA_WIDTH * `AIACC_SA_SIZE)-1:0]   out_mem_din_a;
  logic [(`AIACC_PE_DATA_WIDTH * `AIACC_SA_SIZE)-1:0]   out_mem_dout_a;
  logic                                                 out_mem_wen_a;

  // --------------------------------------------------------------------------
  // Driver Clocking Block
  // --------------------------------------------------------------------------
  clocking drv_cb @(posedge clk);
    // Incoming sync (external drives -> DUT reads)
    output s_axis_sync_q_0_tdata, s_axis_sync_q_0_tvalid;
    input  s_axis_sync_q_0_tready;

    output s_axis_sync_q_1_tdata, s_axis_sync_q_1_tvalid;
    input  s_axis_sync_q_1_tready;

    output s_axis_sync_q_2_tdata, s_axis_sync_q_2_tvalid;
    input  s_axis_sync_q_2_tready;

    output s_axis_sync_q_3_tdata, s_axis_sync_q_3_tvalid;
    input  s_axis_sync_q_3_tready;

    input  axi_str_handshake;

    // Reverse sync (DUT drives -> monitor observes)
    input  s2g_sync_queue_0_tdata, s2g_sync_queue_0_tvalid;
    output s2g_sync_queue_0_tready;

    input  s2g_sync_queue_1_tdata, s2g_sync_queue_1_tvalid;
    output s2g_sync_queue_1_tready;

    input  s2g_sync_queue_2_tdata, s2g_sync_queue_2_tvalid;
    output s2g_sync_queue_2_tready;

    input  s2g_sync_queue_3_tdata, s2g_sync_queue_3_tvalid;
    output s2g_sync_queue_3_tready;

    // Status and memory
    input  barrier_response_store, error_store, store_valid;

    output out_mem_din_a;
    input  out_mem_addr_a, out_mem_en_a, out_mem_dout_a, out_mem_wen_a;
  endclocking

  // ---------------------------------------------------------
  // Monitor Clocking Block
  // ---------------------------------------------------------
  clocking mon_cb @(posedge clk);
    // Observe everything passively
    input s_axis_sync_q_0_tdata, s_axis_sync_q_0_tvalid, s_axis_sync_q_0_tready;
    input s_axis_sync_q_1_tdata, s_axis_sync_q_1_tvalid, s_axis_sync_q_1_tready;
    input s_axis_sync_q_2_tdata, s_axis_sync_q_2_tvalid, s_axis_sync_q_2_tready;
    input s_axis_sync_q_3_tdata, s_axis_sync_q_3_tvalid, s_axis_sync_q_3_tready;

    input s2g_sync_queue_0_tdata, s2g_sync_queue_0_tvalid, s2g_sync_queue_0_tready;
    input s2g_sync_queue_1_tdata, s2g_sync_queue_1_tvalid, s2g_sync_queue_1_tready;
    input s2g_sync_queue_2_tdata, s2g_sync_queue_2_tvalid, s2g_sync_queue_2_tready;
    input s2g_sync_queue_3_tdata, s2g_sync_queue_3_tvalid, s2g_sync_queue_3_tready;

    input barrier_response_store, error_store, store_valid;

    input out_mem_addr_a, out_mem_en_a, out_mem_din_a, out_mem_dout_a, out_mem_wen_a;
  endclocking

  // ---------------------------------------------------------
  // Modports
  // ---------------------------------------------------------

  modport DRV_MP (clocking drv_cb, input rst_n, input clk);
  modport MON_MP (clocking mon_cb, input rst_n, input clk);

endinterface