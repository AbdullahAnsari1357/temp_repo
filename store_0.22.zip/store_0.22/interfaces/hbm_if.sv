//============================================================
// Interface : hbm_if
// Description : AXI4 Write Interface for HBM Agent
//============================================================

interface hbm_if (input logic clk, input logic rst_n);

  // ---------------------------------------------------------
  // AXI Write Address Channel (AW)
  // ---------------------------------------------------------
  logic [(`AIACC_AXI_ADDR_WIDTH-1):0]  m_axi_awaddr;
  logic [7:0]   m_axi_awlen;
  logic [2:0]   m_axi_awsize;
  logic [1:0]   m_axi_awburst;
  logic         m_axi_awvalid;
  logic         m_axi_awready;

  // ---------------------------------------------------------
  // AXI Write Data Channel (W)
  // ---------------------------------------------------------
  logic [(`AIACC_PE_DATA_WIDTH * `AIACC_SA_SIZE)-1:0] m_axi_wdata;
  logic [((`AIACC_PE_DATA_WIDTH * `AIACC_SA_SIZE)/8)-1:0] m_axi_wstrb;
  logic         m_axi_wvalid;
  logic         m_axi_wready;
  logic         m_axi_wlast;

  // ---------------------------------------------------------
  // AXI Write Response Channel (B)
  // ---------------------------------------------------------
  logic         m_axi_bvalid;
  logic         m_axi_bready;
  logic [1:0]   m_axi_bresp;

  // =========================================================
  // Driver Clocking Block (DUT <- HBM)
  // =========================================================
  clocking drv_cb @(posedge clk);

    // AW
    input  m_axi_awaddr, m_axi_awlen;
    input  m_axi_awsize, m_axi_awburst, m_axi_awvalid;

    // W
    input  m_axi_wdata, m_axi_wstrb;
    input  m_axi_wvalid, m_axi_wlast;

    // B
    output m_axi_bvalid, m_axi_bresp;
    input  m_axi_bready;

  endclocking


  // =========================================================
  // Monitor Clocking Block (DUT -> HBM)
  // =========================================================
  clocking mon_cb @(posedge clk);

    // AW
    input m_axi_awaddr;
    input m_axi_awlen;
    input m_axi_awsize;
    input m_axi_awburst;
    input m_axi_awvalid;
    input m_axi_awready;

    // W
    input m_axi_wdata;
    input m_axi_wstrb;
    input m_axi_wvalid;
    input m_axi_wready;
    input m_axi_wlast;

    // B
    input m_axi_bvalid;
    input m_axi_bready;
    input m_axi_bresp;

  endclocking


  // =========================================================
  // Modports
  // =========================================================
  modport DRV_MP (
      clocking drv_cb,
      input  rst_n,
      input  clk,
      output m_axi_awready,
      output m_axi_wready
  );

  modport MON_MP (
      clocking mon_cb,
      input  rst_n,
      input  clk
  );

endinterface : hbm_if